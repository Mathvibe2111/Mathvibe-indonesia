# MathVibe Indonesia - Quick Start Guide

## 🚀 Getting Started

### Prerequisites
- Node.js (v14+)
- MySQL (v5.7+)
- NPM or Yarn

### 1. Setup Database
```bash
# Import database schema
mysql -u root -p mathvibe_indonesia < database/schema.sql

# Import sample data (optional)
mysql -u root -p mathvibe_indonesia < database/seed.sql
```

### 2. Install Dependencies

**Backend:**
```bash
cd backend
npm install
```

**Frontend:**
```bash
cd frontend
npm install
```

### 3. Environment Configuration

**Backend (.env):**
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=mathvibe_indonesia
JWT_SECRET=your-secret-key
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

**Frontend (.env.local):**
```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api
```

### 4. Run Development Server

**Backend:**
```bash
cd backend
npm run dev
```

**Frontend:**
```bash
cd frontend
npm run dev
```

## 📱 Access Points

- **Landing Page:** http://localhost:3000
- **Admin Dashboard:** http://localhost:3000/admin/dashboard
- **CBT Login:** http://localhost:3000/cbt/login
- **API Health:** http://localhost:5000/api/health

## 👤 Default Credentials

### Admin
- **Email:** admin@mathvibe.id
- **Password:** Mathvibe2025

### Demo CBT User
- **Email:** ahmad.fauzan@email.com
- **Password CBT:** MVI-SMP-20241014-0001

## 📁 Project Structure

```
mathvibe-indonesia/
├── backend/           # Express.js API
│   ├── routes/       # API endpoints
│   ├── middleware/   # Custom middleware
│   └── utils/        # Helper functions
├── frontend/         # Next.js Application
│   ├── src/pages/    # Next.js pages
│   └── src/styles/   # CSS files
└── database/         # SQL files
```

## 🛠️ Features

- ✅ Landing page with statistics
- ✅ Registration system with file upload
- ✅ Payment verification
- ✅ Admin dashboard
- ✅ CBT system
- ✅ Email notifications
- ✅ Excel export

## 📞 Support

- WhatsApp: 0822-7497-3133
- Email: admin@mathvibe.id

## 📄 License

MIT License - see LICENSE file for details.