/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['localhost'],
    unoptimized: true,
  },
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api',
    NEXT_PUBLIC_DANA_NUMBER: process.env.NEXT_PUBLIC_DANA_NUMBER || '082274973133',
    NEXT_PUBLIC_BRI_NUMBER: process.env.NEXT_PUBLIC_BRI_NUMBER || '0323-01-009069-53-8',
    NEXT_PUBLIC_ADMIN_PHONE: process.env.NEXT_PUBLIC_ADMIN_PHONE || '082274973133',
    NEXT_PUBLIC_INSTAGRAM_HANDLE: process.env.NEXT_PUBLIC_INSTAGRAM_HANDLE || '@mathvibe.indonesia',
    NEXT_PUBLIC_TIKTOK_HANDLE: process.env.NEXT_PUBLIC_TIKTOK_HANDLE || 'mathvibe.id',
    NEXT_PUBLIC_YOUTUBE_HANDLE: process.env.NEXT_PUBLIC_YOUTUBE_HANDLE || 'mathvibe.id',
    NEXT_PUBLIC_REGISTRATION_FEE: process.env.NEXT_PUBLIC_REGISTRATION_FEE || '30000',
    NEXT_PUBLIC_TOTAL_PRIZE: process.env.NEXT_PUBLIC_TOTAL_PRIZE || '5500000',
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:5000/api/:path*',
      },
    ];
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;