import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { toast, ToastContainer } from 'react-toastify';
import Countdown from 'react-countdown';
import {
  ClockIcon,
  QuestionMarkCircleIcon,
  CheckCircleIcon,
  XCircleIcon,
  ArrowLeftIcon,
  ArrowRightIcon,
  FlagIcon
} from '@heroicons/react/24/outline';

export default function CBTExam() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [examStarted, setExamStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showFinishModal, setShowFinishModal] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);

  // Mock questions for SMP
  const smpQuestions = [
    {
      id: 1,
      question: 'Berapa hasil dari 15 × 12?',
      options: ['180', '160', '140', '120'],
      correct_answer: '180',
      explanation: '15 × 12 = (10 × 12) + (5 × 12) = 120 + 60 = 180'
    },
    {
      id: 2,
      question: 'Jumlah deret 2, 4, 6, ..., 100 adalah?',
      options: ['2550', '2500', '2450', '2400'],
      correct_answer: '2550',
      explanation: 'Ini adalah deret aritmatika dengan a=2, b=2, n=50. Sn = n/2 × (a + Un) = 50/2 × (2 + 100) = 25 × 102 = 2550'
    },
    {
      id: 3,
      question: 'Berapa 3/4 dari 80?',
      options: ['60', '70', '75', '65'],
      correct_answer: '60',
      explanation: '3/4 × 80 = (3 × 80) / 4 = 240 / 4 = 60'
    },
    {
      id: 4,
      question: 'Persentase 25 dari 200 adalah?',
      options: ['12.5%', '15%', '20%', '25%'],
      correct_answer: '12.5%',
      explanation: '(25 / 200) × 100% = 0.125 × 100% = 12.5%'
    },
    {
      id: 5,
      question: 'Hasil dari 2^5 adalah?',
      options: ['32', '64', '16', '128'],
      correct_answer: '32',
      explanation: '2^5 = 2 × 2 × 2 × 2 × 2 = 32'
    }
  ];

  // Mock questions for SMA
  const smaQuestions = [
    {
      id: 1,
      question: 'Jika log₂(x) = 5, maka x = ?',
      options: ['32', '64', '16', '128'],
      correct_answer: '32',
      explanation: 'log₂(x) = 5 ⇒ x = 2^5 = 32'
    },
    {
      id: 2,
      question: 'Berapa suku ke-10 dari barisan 3, 7, 11, 15, ...?',
      options: ['39', '43', '47', '51'],
      correct_answer: '39',
      explanation: 'Barisan aritmatika dengan a=3, b=4. Un = a + (n-1)b = 3 + (10-1)4 = 3 + 36 = 39'
    },
    {
      id: 3,
      question: 'Limit (x² - 1)/(x - 1) saat x→1 adalah?',
      options: ['2', '1', '0', 'Tidak ada'],
      correct_answer: '2',
      explanation: 'lim(x→1) (x²-1)/(x-1) = lim(x→1) (x+1)(x-1)/(x-1) = lim(x→1) (x+1) = 2'
    },
    {
      id: 4,
      question: 'Integral dari 2x dx adalah?',
      options: ['x² + C', '2x + C', 'x + C', '2 + C'],
      correct_answer: 'x² + C',
      explanation: '∫2x dx = 2∫x dx = 2 × (x²/2) + C = x² + C'
    },
    {
      id: 5,
      question: 'Turunan pertama dari f(x) = x³ adalah?',
      options: ['3x²', 'x²', '3x', 'x³'],
      correct_answer: '3x²',
      explanation: 'f(x) = x³ ⇒ f\'(x) = 3x²'
    }
  ];

  const questions = user?.level === 'SMA' ? smaQuestions : smpQuestions;
  const examDuration = user?.level === 'SMA' ? 45 * 60 * 1000 : 30 * 60 * 1000; // 45 menit untuk SMA, 30 menit untuk SMP

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem('cbt_user');
    if (!storedUser) {
      router.push('/cbt/login');
      return;
    }

    const userData = JSON.parse(storedUser);
    setUser(userData);
    setTimeRemaining(examDuration);
    setLoading(false);

    // Prevent tab switching and right click
    const handleVisibilityChange = () => {
      if (document.hidden && examStarted) {
        toast.warning('Jangan keluar dari halaman saat ujian berlangsung!');
      }
    };

    const handleContextMenu = (e) => {
      e.preventDefault();
      toast.warning('Right click dinonaktifkan selama ujian');
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('contextmenu', handleContextMenu);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('contextmenu', handleContextMenu);
    };
  }, [router, examStarted]);

  const startExam = () => {
    setExamStarted(true);
    setTimeRemaining(examDuration);
  };

  const handleAnswerSelect = (questionId, answer) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const navigateQuestion = (direction) => {
    if (direction === 'next' && currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else if (direction === 'prev' && currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const finishExam = () => {
    setShowFinishModal(true);
  };

  const confirmFinish = () => {
    // Calculate score
    let correctAnswers = 0;
    questions.forEach(q => {
      if (answers[q.id] === q.correct_answer) {
        correctAnswers++;
      }
    });

    const score = correctAnswers * 3; // 3 points per correct answer
    
    toast.success(`Ujian selesai! Skor Anda: ${score}`);
    
    // Store results
    localStorage.setItem('cbt_results', JSON.stringify({
      user,
      score,
      correctAnswers,
      totalQuestions: questions.length,
      answers,
      timestamp: new Date().toISOString()
    }));

    setTimeout(() => {
      router.push('/cbt/result');
    }, 2000);
  };

  const countdownRenderer = ({ hours, minutes, seconds, completed }) => {
    if (completed) {
      return (
        <div className="bg-red-100 text-red-800 px-4 py-2 rounded-lg font-bold">
          Waktu Habis!
        </div>
      );
    }

    return (
      <div className="flex items-center space-x-2">
        <ClockIcon className="w-6 h-6 text-primary-600" />
        <span className="text-lg font-mono font-bold">
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </span>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-spinner"></div>
      </div>
    );
  }

  if (!examStarted) {
    return (
      <>
        <Head>
          <title>Mulai Ujian - MathVibe CBT</title>
        </Head>

        <div className="min-h-screen bg-gradient-to-br from-primary-600 to-secondary-500 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="card max-w-2xl w-full"
          >
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-br from-primary-600 to-secondary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <QuestionMarkCircleIcon className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-3xl font-bold gradient-text mb-2">
                Siap Mengikuti Ujian?
              </h1>
              <p className="text-gray-600">
                Pastikan Anda sudah siap sebelum memulai ujian
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-800 mb-2">Informasi Ujian</h3>
                <div className="space-y-2 text-blue-700 text-sm">
                  <div className="flex justify-between">
                    <span>Peserta:</span>
                    <span className="font-medium">{user?.full_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Jenjang:</span>
                    <span className="font-medium">{user?.level}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Jumlah Soal:</span>
                    <span className="font-medium">{questions.length} soal</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Durasi:</span>
                    <span className="font-medium">
                      {user?.level === 'SMA' ? '45 menit' : '30 menit'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h3 className="font-semibold text-yellow-800 mb-2">Perhatian</h3>
                <ul className="text-yellow-700 text-sm space-y-1">
                  <li>• Pastikan koneksi internet stabil</li>
                  <li>• Jangan keluar dari halaman selama ujian</li>
                  <li>• Sistem akan otomatis submit saat waktu habis</li>
                  <li>• Right click dan copy paste dinonaktifkan</li>
                </ul>
              </div>

              <button
                onClick={startExam}
                className="btn-primary w-full"
              >
                Mulai Ujian
              </button>
            </div>
          </motion.div>
        </div>

        <ToastContainer position="top-right" />
      </>
    );
  }

  return (
    <>
      <Head>
        <title>Ujian Berlangsung - MathVibe CBT</title>
      </Head>

      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="container-custom py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-xl font-bold gradient-text">MathVibe CBT</h1>
                <p className="text-sm text-gray-600">{user?.full_name} - {user?.level}</p>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <p className="text-sm text-gray-600">Soal</p>
                  <p className="font-bold">
                    {currentQuestion + 1} / {questions.length}
                  </p>
                </div>
                
                <div className="text-center">
                  <Countdown
                    date={Date.now() + timeRemaining}
                    renderer={countdownRenderer}
                    onComplete={() => confirmFinish()}
                  />
                </div>
                
                <button
                  onClick={() => setShowFinishModal(true)}
                  className="btn-outline text-sm py-2 px-4"
                >
                  <FlagIcon className="w-4 h-4 inline mr-1" />
                  Selesai
                </button>
              </div>
            </div>
          </div>
        </header>

        <div className="container-custom py-8">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Question Navigation */}
            <div className="lg:col-span-1">
              <div className="card sticky top-4">
                <h3 className="font-semibold mb-4">Navigasi Soal</h3>
                <div className="grid grid-cols-5 gap-2">
                  {questions.map((q, index) => (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQuestion(index)}
                      className={`w-10 h-10 rounded-lg text-sm font-medium transition-colors ${
                        currentQuestion === index
                          ? 'bg-primary-600 text-white'
                          : answers[q.id]
                          ? 'bg-green-100 text-green-800 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {index + 1}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Question Content */}
            <div className="lg:col-span-3">
              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="card"
              >
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-primary-100 text-primary-800 px-3 py-1 rounded-full text-sm font-medium">
                      Soal {currentQuestion + 1}
                    </span>
                  </div>
                  
                  <h2 className="text-xl font-semibold mb-6">
                    {questions[currentQuestion].question}
                  </h2>

                  <div className="space-y-3">
                    {questions[currentQuestion].options.map((option, index) => (
                      <label
                        key={index}
                        className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                          answers[questions[currentQuestion].id] === option
                            ? 'border-primary-500 bg-primary-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`question_${questions[currentQuestion].id}`}
                          value={option}
                          checked={answers[questions[currentQuestion].id] === option}
                          onChange={() => handleAnswerSelect(questions[currentQuestion].id, option)}
                          className="mr-3 text-primary-600 focus:ring-primary-500"
                        />
                        <span className="font-medium">{String.fromCharCode(65 + index)}.</span>
                        <span className="ml-2">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Navigation Buttons */}
                <div className="flex items-center justify-between pt-6 border-t">
                  <button
                    onClick={() => navigateQuestion('prev')}
                    disabled={currentQuestion === 0}
                    className="btn-outline disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ArrowLeftIcon className="w-5 h-5 inline mr-2" />
                    Sebelumnya
                  </button>

                  <div className="text-center">
                    <p className="text-sm text-gray-600">
                      {Object.keys(answers).length} dari {questions.length} soal terjawab
                    </p>
                  </div>

                  <button
                    onClick={() => navigateQuestion('next')}
                    disabled={currentQuestion === questions.length - 1}
                    className="btn-outline disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Selanjutnya
                    <ArrowRightIcon className="w-5 h-5 inline ml-2" />
                  </button>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      {/* Finish Confirmation Modal */}
      {showFinishModal && (
        <div className="modal-overlay">
          <div className="modal-content max-w-md">
            <div className="p-6">
              <h3 className="text-xl font-bold mb-4 text-center">
                Selesaikan Ujian?
              </h3>
              
              <div className="text-center mb-6">
                <div className="text-6xl mb-4">📝</div>
                <p className="text-gray-600 mb-4">
                  Anda telah menjawab {Object.keys(answers).length} dari {questions.length} soal.
                </p>
                <p className="text-sm text-gray-500">
                  Pastikan semua jawaban sudah benar sebelum menyelesaikan ujian.
                </p>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => setShowFinishModal(false)}
                  className="btn-outline flex-1"
                >
                  Kembali
                </button>
                <button
                  onClick={confirmFinish}
                  className="btn-primary flex-1"
                >
                  <CheckCircleIcon className="w-5 h-5 inline mr-2" />
                  Selesaikan Ujian
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <ToastContainer position="top-right" />
    </>
  );
}