import React, { useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { toast, ToastContainer } from 'react-toastify';
import { KeyIcon, UserIcon } from '@heroicons/react/24/outline';

export default function CBTLogin() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState({
    email: '',
    password: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Mock authentication
      const mockUsers = [
        {
          email: 'ahmad.fauzan@email.com',
          password: 'MVI-SMP-20241014-0001',
          full_name: 'Ahmad Fauzan',
          level: 'SMP',
          id: 1
        },
        {
          email: 'budi.santoso@email.com',
          password: 'MVI-SMP-20241014-0003',
          full_name: 'Budi Santoso',
          level: 'SMP',
          id: 3
        },
        {
          email: 'siti.nurhaliza@email.com',
          password: 'MVI-SMA-20241014-0002',
          full_name: 'Siti Nurhaliza',
          level: 'SMA',
          id: 2
        }
      ];

      const user = mockUsers.find(
        u => u.email === credentials.email && u.password === credentials.password
      );

      if (user) {
        toast.success('Login berhasil!');
        
        // Store user data
        localStorage.setItem('cbt_user', JSON.stringify(user));
        
        // Redirect to exam
        setTimeout(() => {
          router.push('/cbt/exam');
        }, 1500);
      } else {
        toast.error('Email atau password salah');
      }

    } catch (error) {
      toast.error('Terjadi kesalahan saat login');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setCredentials({
      ...credentials,
      [e.target.name]: e.target.value
    });
  };

  return (
    <>
      <Head>
        <title>Login CBT - MathVibe Indonesia</title>
        <meta name="description" content="Login Computer Based Test MathVibe Indonesia" />
      </Head>

      <div className="min-h-screen bg-gradient-to-br from-primary-600 to-secondary-500 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="card max-w-md w-full"
        >
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-primary-600 to-secondary-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <KeyIcon className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold gradient-text mb-2">
              MathVibe CBT
            </h1>
            <p className="text-gray-600">
              Computer Based Test - Olimpiade Matematika
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="form-label">
                <UserIcon className="w-4 h-4 inline mr-2" />
                Email
              </label>
              <input
                type="email"
                name="email"
                className="form-input"
                placeholder="Masukkan email Anda"
                value={credentials.email}
                onChange={handleChange}
                required
              />
            </div>

            <div>
              <label className="form-label">
                <KeyIcon className="w-4 h-4 inline mr-2" />
                Password CBT
              </label>
              <input
                type="password"
                name="password"
                className="form-input"
                placeholder="Masukkan password CBT"
                value={credentials.password}
                onChange={handleChange}
                required
              />
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800 text-sm">
                <strong>Demo Account:</strong><br />
                Email: ahmad.fauzan@email.com<br />
                Password: MVI-SMP-20241014-0001
              </p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="loading-spinner mr-2"></div>
                  Sedang login...
                </div>
              ) : (
                'Login ke CBT'
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <a
              href="https://wa.me/6282274973133"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary-600 hover:text-primary-800 text-sm"
            >
              Lupa password? Hubungi admin
            </a>
          </div>
        </motion.div>
      </div>

      <ToastContainer position="top-right" />
    </>
  );
}