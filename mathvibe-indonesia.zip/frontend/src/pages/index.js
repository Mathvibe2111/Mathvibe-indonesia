import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { 
  AcademicCapIcon, 
  TrophyIcon, 
  UsersIcon, 
  MapIcon, 
  CurrencyDollarIcon,
  CheckCircleIcon,
  ClockIcon,
  ShieldCheckIcon
} from '@heroicons/react/24/outline';

export default function Home() {
  const [stats, setStats] = useState({
    total_registered: 250,
    total_paid: 250,
    total_provinces: 15,
    total_prize: 'Rp 5.500.000'
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading real statistics
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  const features = [
    {
      icon: AcademicCapIcon,
      title: 'Kompetisi Adil',
      description: 'Sistem penilaian transparan dan fair untuk semua peserta'
    },
    {
      icon: TrophyIcon,
      title: 'Hadiah Menarik',
      description: 'Total hadiah Rp 5.5 juta untuk pemenang'
    },
    {
      icon: UsersIcon,
      title: 'Untuk Semua',
      description: 'Terbuka untuk siswa SMP dan SMA seluruh Indonesia'
    },
    {
      icon: ShieldCheckIcon,
      title: 'Anti Curang',
      description: 'Sistem pengawasan ketat untuk mencegah kecurangan'
    }
  ];

  const timeline = [
    {
      date: '19 Okt - 9 Nov 2024',
      title: 'Pendaftaran',
      description: 'Buka pendaftaran peserta'
    },
    {
      date: '16 - 20 Nov 2024',
      title: 'Babak Penyisihan',
      description: 'Ujian online sistem CBT'
    },
    {
      date: '25 Nov 2024',
      title: 'Babak Final',
      description: 'Final dengan pengawasan Zoom'
    },
    {
      date: '27 Nov 2024',
      title: 'Pengumuman',
      description: 'Pengumuman pemenang'
    }
  ];

  const paymentMethods = [
    {
      name: 'DANA',
      number: '082274973133',
      holder: 'SOFYAN HADI',
      color: 'bg-blue-100 text-blue-800'
    },
    {
      name: 'Bank BRI',
      number: '0323-01-009069-53-8',
      holder: 'ROSI EVI SUSANTI',
      color: 'bg-green-100 text-green-800'
    }
  ];

  return (
    <>
      <Head>
        <title>MathVibe Indonesia - Balapan Angka, Asah Logika!</title>
        <meta name="description" content="Olimpiade Matematika Indonesia untuk SMP dan SMA dengan total hadiah Rp 5.5 juta" />
        <meta name="keywords" content="olimpiade matematika, mathvibe, indonesia, smp, sma, kompetisi" />
        <meta property="og:title" content="MathVibe Indonesia - Balapan Angka, Asah Logika!" />
        <meta property="og:description" content="Olimpiade Matematika Indonesia untuk SMP dan SMA dengan total hadiah Rp 5.5 juta" />
        <meta property="og:type" content="website" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      {/* Hero Section */}
      <section className="hero-bg min-h-screen flex items-center">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-white"
            >
              <h1 className="text-5xl lg:text-7xl font-bold mb-6">
                MathVibe
                <span className="block text-4xl lg:text-6xl mt-2 opacity-90">Indonesia</span>
              </h1>
              <p className="text-2xl lg:text-3xl mb-8 font-light opacity-95">
                "Balapan Angka, Asah Logika!"
              </p>
              <p className="text-lg mb-12 opacity-90 leading-relaxed">
                Olimpiade matematika nasional untuk siswa SMP dan SMA dengan sistem kompetisi yang adil, 
                transparan, dan penuh tantangan. Tunjukkan kemampuan berhitungmu dan raih hadiahnya!
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/register" className="btn-primary bg-white text-primary-600 hover:bg-gray-100 inline-block text-center">
                  Daftar Sekarang
                </Link>
                <Link href="/info" className="btn-outline border-white text-white hover:bg-white hover:text-primary-600 inline-block text-center">
                  Info Lengkap
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="grid grid-cols-2 gap-6"
            >
              {loading ? (
                <div className="col-span-2 flex justify-center">
                  <div className="loading-spinner"></div>
                </div>
              ) : (
                <>
                  <div className="card bg-white/10 backdrop-blur-sm border-white/20 text-white">
                    <div className="text-center">
                      <UsersIcon className="w-12 h-12 mx-auto mb-4 opacity-80" />
                      <div className="text-3xl font-bold mb-2">{stats.total_registered}</div>
                      <div className="text-sm opacity-80">Peserta Terdaftar</div>
                    </div>
                  </div>
                  <div className="card bg-white/10 backdrop-blur-sm border-white/20 text-white">
                    <div className="text-center">
                      <CheckCircleIcon className="w-12 h-12 mx-auto mb-4 opacity-80" />
                      <div className="text-3xl font-bold mb-2">{stats.total_paid}</div>
                      <div className="text-sm opacity-80">Sudah Bayar</div>
                    </div>
                  </div>
                  <div className="card bg-white/10 backdrop-blur-sm border-white/20 text-white">
                    <div className="text-center">
                      <MapIcon className="w-12 h-12 mx-auto mb-4 opacity-80" />
                      <div className="text-3xl font-bold mb-2">{stats.total_provinces}</div>
                      <div className="text-sm opacity-80">Provinsi</div>
                    </div>
                  </div>
                  <div className="card bg-white/10 backdrop-blur-sm border-white/20 text-white">
                    <div className="text-center">
                      <CurrencyDollarIcon className="w-12 h-12 mx-auto mb-4 opacity-80" />
                      <div className="text-3xl font-bold mb-2">5.5 JT</div>
                      <div className="text-sm opacity-80">Total Hadiah</div>
                    </div>
                  </div>
                </>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold gradient-text mb-6">
              Kenapa MathVibe Indonesia?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Kompetisi matematika dengan sistem yang adil, transparan, dan mengutamakan kemampuan peserta
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="card card-hover text-center"
              >
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <feature.icon className="w-8 h-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold mb-4">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold gradient-text mb-6">
              Jadwal Kegiatan
            </h2>
            <p className="text-xl text-gray-600">
                Ikuti setiap tahapan kompetisi dengan baik
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {timeline.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="card text-center"
              >
                <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <ClockIcon className="w-8 h-8 text-secondary-600" />
                </div>
                <div className="text-sm text-secondary-600 font-semibold mb-2">{item.date}</div>
                <h3 className="text-xl font-semibold mb-4">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Payment Info Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-bold gradient-text mb-6">
              Biaya Pendaftaran
            </h2>
            <div className="text-6xl font-bold text-primary-600 mb-4">
              <span className="line-through text-gray-400 text-4xl">Rp 50.000</span>
              <span className="text-secondary-500 ml-4">Rp 30.000</span>
            </div>
            <p className="text-xl text-gray-600">Diskon Launching Terbatas!</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {paymentMethods.map((method, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="card"
              >
                <div className="text-center mb-6">
                  <h3 className={`text-2xl font-bold ${method.color} px-4 py-2 rounded-lg inline-block`}>
                    {method.name}
                  </h3>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="form-label">Nomor Rekening</label>
                    <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                      <span className="font-mono text-lg">{method.number}</span>
                      <button
                        onClick={() => navigator.clipboard.writeText(method.number)}
                        className="btn-primary text-sm py-1 px-3"
                      >
                        Salin
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="form-label">Atas Nama</label>
                    <div className="bg-gray-50 p-3 rounded-lg font-semibold">
                      {method.holder}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding hero-bg">
        <div className="container-custom text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto text-white"
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              Siap Berkompetisi?
            </h2>
            <p className="text-xl mb-12 opacity-90">
              Jangan lewatkan kesempatan untuk menunjukkan kemampuan matematikamu 
              dan raih hadiahnya!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/register" className="btn-primary bg-white text-primary-600 hover:bg-gray-100 inline-block text-center">
                Daftar Sekarang
              </Link>
              <Link href="/info" className="btn-outline border-white text-white hover:bg-white hover:text-primary-600 inline-block text-center">
                Baca Petunjuk
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
}