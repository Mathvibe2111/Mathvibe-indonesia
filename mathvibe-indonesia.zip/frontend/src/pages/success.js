import React from 'react';
import Head from 'next/head';
import { motion } from 'framer-motion';
import { CheckCircleIcon, HomeIcon, InformationCircleIcon } from '@heroicons/react/24/outline';

export default function Success() {
  return (
    <>
      <Head>
        <title>Pendaftaran Berhasil - MathVibe Indonesia</title>
        <meta name="description" content="Pendaftaran MathVibe Indonesia berhasil dikirim" />
      </Head>

      <div className="min-h-screen bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="card max-w-md w-full text-center"
        >
          <div className="mb-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircleIcon className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Pendaftaran Berhasil!
            </h1>
            <p className="text-gray-600">
              Terima kasih telah mendaftar di MathVibe Indonesia
            </p>
          </div>

          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-800 mb-2">Selanjutnya:</h3>
              <ul className="text-blue-700 text-sm space-y-1 text-left">
                <li>✓ Tim kami akan memverifikasi pembayaran Anda</li>
                <li>✓ Password CBT akan dikirim via email</li>
                <li>✓ Simpan email tersebut dengan aman</li>
                <li>✓ Siapkan diri untuk ujian penyisihan</li>
              </ul>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start">
                <InformationCircleIcon className="w-6 h-6 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                <div className="text-yellow-800 text-sm">
                  <p className="font-semibold mb-1">Penting:</p>
                  <p>Proses verifikasi membutuhkan 1-2 hari kerja. Anda akan menerima notifikasi via email saat pembayaran terverifikasi.</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="/"
                className="btn-primary flex-1"
              >
                <HomeIcon className="w-5 h-5 inline mr-2" />
                Kembali ke Home
              </a>
              <a
                href="/info"
                className="btn-outline flex-1"
              >
                <InformationCircleIcon className="w-5 h-5 inline mr-2" />
                Baca Petunjuk
              </a>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t text-center">
            <p className="text-sm text-gray-500">
              Punya pertanyaan? Hubungi kami via{' '}
              <a
                href="https://wa.me/6282274973133"
                className="text-primary-600 hover:text-primary-800 font-medium"
                target="_blank"
                rel="noopener noreferrer"
              >
                WhatsApp
              </a>
            </p>
          </div>
        </motion.div>
      </div>
    </>
  );
}