import React, { useState } from 'react';
import Head from 'next/head';
import { motion } from 'framer-motion';
import {
  DocumentTextIcon,
  ClockIcon,
  ShieldCheckIcon,
  CurrencyDollarIcon,
  AcademicCapIcon,
  TrophyIcon,
  UsersIcon,
  InformationCircleIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  CameraIcon,
  WifiIcon
} from '@heroicons/react/24/outline';

export default function Info() {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', name: 'Overview', icon: InformationCircleIcon },
    { id: 'registration', name: 'Pendaftaran', icon: DocumentTextIcon },
    { id: 'exam', name: 'Sistem Ujian', icon: AcademicCapIcon },
    { id: 'rules', name: 'Peraturan', icon: ShieldCheckIcon },
    { id: 'faq', name: 'FAQ', icon: InformationCircleIcon }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-primary-600 to-secondary-500 text-white rounded-lg p-8">
              <h2 className="text-3xl font-bold mb-4">Tentang MathVibe Indonesia</h2>
              <p className="text-lg leading-relaxed">
                MathVibe Indonesia adalah olimpiade matematika nasional yang dipersembahkan untuk 
                siswa SMP dan SMA seluruh Indonesia. Dengan tagline "Balapan Angka, Asah Logika!", 
                kami menciptakan wadah kompetisi yang adil, transparan, dan penuh tantangan.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-2xl font-bold mb-4 flex items-center">
                  <TrophyIcon className="w-8 h-8 mr-3 text-secondary-500" />
                  Visi Kami
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  Menciptakan wadah kompetisi berhitung cepat dan logis bagi pelajar Indonesia 
                  dengan sistem yang adil, jujur, transparan, dan kompetitif.
                </p>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-4 flex items-center">
                  <UsersIcon className="w-8 h-8 mr-3 text-primary-600" />
                  Misi Kami
                </h3>
                <ul className="text-gray-600 space-y-2">
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Melatih kecepatan dan ketepatan berhitung matematika
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Menumbuhkan semangat kompetisi yang sehat
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Memberikan kesempatan yang sama kepada semua siswa
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Memberikan penghargaan sepenuhnya gratis
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-2xl font-bold mb-4">Jadwal Kegiatan</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center">
                    <ClockIcon className="w-6 h-6 text-primary-600 mr-3" />
                    <div>
                      <div className="font-semibold">Pendaftaran</div>
                      <div className="text-sm text-gray-600">19 Okt - 9 Nov 2024</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <ClockIcon className="w-6 h-6 text-secondary-600 mr-3" />
                    <div>
                      <div className="font-semibold">Babak Penyisihan</div>
                      <div className="text-sm text-gray-600">16 - 20 Nov 2024</div>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <ClockIcon className="w-6 h-6 text-green-600 mr-3" />
                    <div>
                      <div className="font-semibold">Babak Final</div>
                      <div className="text-sm text-gray-600">25 Nov 2024</div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <ClockIcon className="w-6 h-6 text-purple-600 mr-3" />
                    <div>
                      <div className="font-semibold">Pengumuman</div>
                      <div className="text-sm text-gray-600">27 Nov 2024</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'registration':
        return (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg p-8">
              <h2 className="text-3xl font-bold mb-4">Panduan Pendaftaran</h2>
              <p className="text-lg">
                Ikuti langkah-langkah pendaftaran dengan seksama untuk memastikan 
                partisipasi Anda dalam kompetisi ini.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <CurrencyDollarIcon className="w-6 h-6 mr-2 text-green-600" />
                  Biaya Pendaftaran
                </h3>
                <div className="text-center">
                  <div className="text-4xl font-bold text-secondary-500 mb-2">
                    Rp 30.000
                  </div>
                  <div className="text-lg text-gray-500 line-through mb-4">
                    Rp 50.000
                  </div>
                  <p className="text-sm text-gray-600">
                    Diskon launching terbatas! <br />
                    Biaya sudah termasuk semua fasilitas.
                  </p>
                </div>
              </div>

              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <ShieldCheckIcon className="w-6 h-6 mr-2 text-blue-600" />
                  Syarat Peserta
                </h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Siswa aktif SMP/SMA di Indonesia
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Memiliki akses internet stabil
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Memiliki perangkat (laptop/HP/tablet)
                  </li>
                  <li className="flex items-start">
                    <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    Bersedia mematuhi semua peraturan
                  </li>
                </ul>
              </div>
            </div>

            <div className="card">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <DocumentTextIcon className="w-6 h-6 mr-2 text-purple-600" />
                Langkah Pendaftaran
              </h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Isi Formulir Pendaftaran</h4>
                    <p className="text-gray-600 text-sm">
                      Lengkapi data diri, sekolah, dan informasi kontak dengan benar.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Upload Bukti Sosial Media</h4>
                    <p className="text-gray-600 text-sm">
                      Screenshot bukti follow, like, comment, dan share postingan MathVibe.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Lakukan Pembayaran</h4>
                    <p className="text-gray-600 text-sm">
                      Transfer biaya pendaftaran ke rekening yang tersedia.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Upload Bukti Pembayaran</h4>
                    <p className="text-gray-600 text-sm">
                      Upload screenshot atau foto bukti transfer pembayaran.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    5
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Tunggu Verifikasi</h4>
                    <p className="text-gray-600 text-sm">
                      Admin akan memverifikasi pembayaran dan mengirim password CBT via email.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'exam':
        return (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-lg p-8">
              <h2 className="text-3xl font-bold mb-4">Sistem Ujian CBT</h2>
              <p className="text-lg">
                Computer Based Test (CBT) dengan sistem yang aman dan terintegrasi 
                untuk memastikan kenyamanan dan keamanan selama ujian.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <AcademicCapIcon className="w-6 h-6 mr-2 text-blue-600" />
                  Babak Penyisihan
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">SMP:</span>
                    <span className="font-medium">30 soal / 30 menit</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">SMA:</span>
                    <span className="font-medium">40 soal / 45 menit</span>
                  </div>
                  <div className="border-t pt-3">
                    <p className="text-sm text-gray-600">
                      <strong>Skor:</strong> Benar +3, Salah -1, Kosong 0
                    </p>
                  </div>
                </div>
              </div>

              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <TrophyIcon className="w-6 h-6 mr-2 text-yellow-600" />
                  Babak Final
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">SMP:</span>
                    <span className="font-medium">15 soal × 15 detik</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">SMA:</span>
                    <span className="font-medium">20 soal × 20 detik</span>
                  </div>
                  <div className="border-t pt-3">
                    <p className="text-sm text-gray-600">
                      <strong>Skor:</strong> Benar +3, Salah 0, Kosong 0
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="card">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <CameraIcon className="w-6 h-6 mr-2 text-red-600" />
                Persyaratan Sistem
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">Perangkat Keras</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      Laptop/PC (recommended) atau HP/Tablet
                    </li>
                    <li className="flex items-start">
                      <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      Kamera web untuk babak final
                    </li>
                    <li className="flex items-start">
                      <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      Mikrofon untuk komunikasi
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Perangkat Lunak</h4>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      Browser terbaru (Chrome/Firefox)
                    </li>
                    <li className="flex items-start">
                      <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      Zoom untuk babak final
                    </li>
                    <li className="flex items-start">
                      <CheckCircleIcon className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      Koneksi internet stabil minimum 1 Mbps
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center text-red-800">
                <ExclamationTriangleIcon className="w-6 h-6 mr-2" />
                Larangan Selama Ujian
              </h3>
              <div className="grid md:grid-cols-2 gap-6 text-red-700">
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <XCircleIcon className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                    Menggunakan kalkulator atau alat bantu
                  </li>
                  <li className="flex items-start">
                    <XCircleIcon className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                    Menyontek atau bekerja sama
                  </li>
                  <li className="flex items-start">
                    <XCircleIcon className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                    Keluar dari halaman ujian
                  </li>
                </ul>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <XCircleIcon className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                    Menggunakan AI atau software bantu
                  </li>
                  <li className="flex items-start">
                    <XCircleIcon className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                    Membuka tab atau aplikasi lain
                  </li>
                  <li className="flex items-start">
                    <XCircleIcon className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                    Menyalakan kamera di babak final
                  </li>
                </ul>
              </div>
            </div>
          </div>
        );

      case 'rules':
        return (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-red-600 to-orange-600 text-white rounded-lg p-8">
              <h2 className="text-3xl font-bold mb-4">Peraturan & Sanksi</h2>
              <p className="text-lg">
                Semua peserta wajib mematuhi peraturan untuk menjaga keteraturan 
                dan sportivitas dalam kompetisi.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center text-green-600">
                  <CheckCircleIcon className="w-6 h-6 mr-2" />
                  Peraturan Umum
                </h3>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      1
                    </div>
                    <span>Menjadi siswa aktif dan memiliki kartu pelajar</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      2
                    </div>
                    <span>Mengikuti semua tahapan kompetisi sesuai jadwal</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      3
                    </div>
                    <span>Mematuhi instruksi panitia selama kompetisi</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      4
                    </div>
                    <span>Menjaga sportivitas dan etika kompetisi</span>
                  </li>
                </ul>
              </div>

              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center text-red-600">
                  <ExclamationTriangleIcon className="w-6 h-6 mr-2" />
                  Pelanggaran Berat
                </h3>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      ⚠
                    </div>
                    <span>Menyontek atau bekerja sama dengan peserta lain</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      ⚠
                    </div>
                    <span>Menggunakan alat bantu atau kalkulator</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      ⚠
                    </div>
                    <span>Menggunakan AI atau software bantu lainnya</span>
                  </li>
                  <li className="flex items-start">
                    <div className="w-6 h-6 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-xs font-bold mr-3 mt-0.5 flex-shrink-0">
                      ⚠
                    </div>
                    <span>Memalsukan identitas atau data pribadi</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-red-800 flex items-center">
                <ExclamationTriangleIcon className="w-6 h-6 mr-2" />
                Sanksi Pelanggaran
              </h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-red-800">Peringatan</h4>
                    <p className="text-red-700 text-sm">Untuk pelanggaran ringan pertama kali</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-red-800">Pengurangan Nilai</h4>
                    <p className="text-red-700 text-sm">Untuk pelanggaran sedang atau berulang</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-red-100 text-red-600 rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-red-800">Diskualifikasi</h4>
                    <p className="text-red-700 text-sm">Untuk pelanggaran berat atau kecurangan</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-blue-800 flex items-center">
                <InformationCircleIcon className="w-6 h-6 mr-2" />
                Proses Banding
              </h3>
              <p className="text-blue-700 text-sm mb-4">
                Peserta yang merasa tidak puas dengan keputusan panitia dapat mengajukan banding 
                dalam waktu 24 jam setelah pengumuman dengan ketentuan:
              </p>
              <ul className="text-blue-700 text-sm space-y-1">
                <li>• Mengirimkan bukti pendukung yang kuat</li>
                <li>• Menyampaikan alasan yang jelas dan logis</li>
                <li>• Keputusan panitia bersifat final dan mengikat</li>
              </ul>
            </div>
          </div>
        );

      case 'faq':
        return (
          <div className="space-y-8">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg p-8">
              <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-lg">
                Temukan jawaban atas pertanyaan yang sering diajukan mengenai 
                kompetisi MathVibe Indonesia.
              </p>
            </div>

            <div className="space-y-4">
              {[
                {
                  question: 'Apakah kompetisi ini benar-benar gratis?',
                  answer: 'Ya, kompetisi ini 100% gratis tanpa biaya tambahan tersembunyi. Biaya pendaftaran hanya Rp 30.000 (diskon dari Rp 50.000) dan sudah termasuk semua fasilitas.'
                },
                {
                  question: 'Bagaimana sistem penilaiannya?',
                  answer: 'Penyisihan: Benar +3 poin, Salah -1 poin, Kosong 0 poin. Final: Benar +3 poin, Salah 0 poin, Kosong 0 poin. Peringkat dihitung dari total skor tertinggi.'
                },
                {
                  question: 'Apakah semua peserta mendapat sertifikat?',
                  answer: 'Sertifikat digital akan diberikan kepada semua peserta yang menyelesaikan ujian. Sertifikat khusus pemenang akan dikirim secara fisik.'
                },
                {
                  question: 'Bagaimana jika koneksi internet terputus?',
                  answer: 'Sistem akan menyimpan progress terakhir. Peserta dapat melanjutkan dengan login kembali, namun timer tidak akan berhenti.'
                },
                {
                  question: 'Apakah boleh menggunakan kalkulator?',
                  answer: 'Tidak diperbolehkan. Semua perhitungan harus dilakukan manual. Penggunaan alat bantu akan dikenakan sanksi diskualifikasi.'
                },
                {
                  question: 'Kapan pengumuman pemenang?',
                  answer: 'Pengumuman pemenang akan dilakukan pada 27 November 2024 melalui website resmi dan media sosial MathVibe Indonesia.'
                }
              ].map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="card"
                >
                  <h3 className="font-semibold text-lg mb-2 text-primary-600">
                    {faq.question}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {faq.answer}
                  </p>
                </motion.div>
              ))}
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 text-yellow-800 flex items-center">
                <InformationCircleIcon className="w-6 h-6 mr-2" />
                Masih Ada Pertanyaan?
              </h3>
              <p className="text-yellow-700 text-sm mb-4">
                Jika pertanyaan Anda belum terjawab, silakan hubungi kami melalui:
              </p>
              <div className="space-y-2 text-yellow-700 text-sm">
                <div className="flex items-center">
                  <CheckCircleIcon className="w-4 h-4 mr-2" />
                  <span>WhatsApp: 0822-7497-3133</span>
                </div>
                <div className="flex items-center">
                  <CheckCircleIcon className="w-4 h-4 mr-2" />
                  <span>Email: admin@mathvibe.id</span>
                </div>
                <div className="flex items-center">
                  <CheckCircleIcon className="w-4 h-4 mr-2" />
                  <span>Instagram: @mathvibe.indonesia</span>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <Head>
        <title>Informasi - MathVibe Indonesia</title>
        <meta name="description" content="Informasi lengkap tentang Olimpiade Matematika MathVibe Indonesia" />
      </Head>

      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="container-custom py-6">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <h1 className="text-4xl font-bold gradient-text mb-2">
                Informasi & Petunjuk
              </h1>
              <p className="text-gray-600">
                Panduan lengkap untuk mengikuti Olimpiade Matematika MathVibe Indonesia
              </p>
            </motion.div>
          </div>
        </header>

        {/* Navigation Tabs */}
        <nav className="bg-white border-b sticky top-0 z-10">
          <div className="container-custom">
            <div className="flex overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center px-6 py-4 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'text-primary-600 border-b-2 border-primary-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <tab.icon className="w-5 h-5 mr-2" />
                  {tab.name}
                </button>
              ))}
            </div>
          </div>
        </nav>

        {/* Content */}
        <main className="py-8">
          <div className="container-custom">
            {renderTabContent()}
          </div>
        </main>
      </div>
    </>
  );
}