import React, { useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { toast, ToastContainer } from 'react-toastify';
import { 
  CreditCardIcon, 
  BanknotesIcon, 
  DocumentArrowUpIcon,
  CheckCircleIcon,
  InformationCircleIcon
} from '@heroicons/react/24/outline';

export default function Payment() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [selectedMethod, setSelectedMethod] = useState('');

  const paymentMethods = [
    {
      id: 'dana',
      name: 'DANA',
      number: '082274973133',
      holder: 'SOFYAN HADI',
      icon: CreditCardIcon,
      color: 'bg-blue-100 text-blue-800',
      description: 'Transfer via aplikasi DANA'
    },
    {
      id: 'bri',
      name: 'Bank BRI',
      number: '0323-01-009069-53-8',
      holder: 'ROSI EVI SUSANTI',
      icon: BanknotesIcon,
      color: 'bg-green-100 text-green-800',
      description: 'Transfer via ATM/Bank'
    }
  ];

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    
    if (!file) return;

    const maxSize = 10 * 1024 * 1024; // 10MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];

    if (file.size > maxSize) {
      toast.error('File melebihi ukuran maksimal 10MB');
      return;
    }

    if (!allowedTypes.includes(file.type)) {
      toast.error('File harus berformat JPG, PNG, atau PDF');
      return;
    }

    setUploadedFile(file);
    
    if (file.type.startsWith('image/')) {
      const preview = URL.createObjectURL(file);
      setFilePreview(preview);
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    setFilePreview(null);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Nomor berhasil disalin!');
  };

  const handleSubmit = async () => {
    if (!selectedMethod) {
      toast.error('Pilih metode pembayaran terlebih dahulu');
      return;
    }

    if (!uploadedFile) {
      toast.error('Upload bukti pembayaran terlebih dahulu');
      return;
    }

    setLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));

      toast.success('Bukti pembayaran berhasil diupload!');
      
      // Show success message and redirect
      setTimeout(() => {
        router.push('/success');
      }, 2000);

    } catch (error) {
      toast.error('Terjadi kesalahan saat upload bukti pembayaran');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Head>
        <title>Pembayaran - MathVibe Indonesia</title>
        <meta name="description" content="Upload bukti pembayaran MathVibe Indonesia" />
      </Head>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container-custom max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="card"
          >
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold gradient-text mb-4">
                Pembayaran Pendaftaran
              </h1>
              <p className="text-gray-600">
                Selesaikan pembayaran dan upload bukti untuk menyelesaikan pendaftaran
              </p>
            </div>

            {/* Payment Amount */}
            <div className="bg-gradient-to-r from-primary-600 to-secondary-500 text-white rounded-lg p-6 mb-8 text-center">
              <h2 className="text-2xl font-semibold mb-2">Total Biaya Pendaftaran</h2>
              <div className="text-5xl font-bold mb-2">
                <span className="line-through text-2xl opacity-75">Rp 50.000</span>
                <span className="ml-4">Rp 30.000</span>
              </div>
              <p className="text-sm opacity-90">Diskon Launching Terbatas!</p>
            </div>

            {/* Payment Methods */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4">Pilih Metode Pembayaran</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    onClick={() => setSelectedMethod(method.id)}
                    className={`card card-hover cursor-pointer transition-all ${
                      selectedMethod === method.id 
                        ? 'ring-2 ring-primary-500 bg-primary-50' 
                        : ''
                    }`}
                  >
                    <div className="flex items-center mb-4">
                      <method.icon className={`w-8 h-8 mr-3 ${method.color.split(' ')[1]}`} />
                      <div>
                        <h4 className="font-semibold text-lg">{method.name}</h4>
                        <p className="text-sm text-gray-600">{method.description}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium text-gray-700">Nomor Rekening</label>
                        <div className="flex items-center justify-between bg-gray-50 p-3 rounded-lg mt-1">
                          <span className="font-mono text-lg">{method.number}</span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              copyToClipboard(method.number);
                            }}
                            className="btn-primary text-sm py-1 px-3"
                          >
                            Salin
                          </button>
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium text-gray-700">Atas Nama</label>
                        <div className="bg-gray-50 p-3 rounded-lg mt-1 font-semibold">
                          {method.holder}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Upload Payment Proof */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <DocumentArrowUpIcon className="w-6 h-6 mr-2" />
                Upload Bukti Pembayaran
              </h3>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <div className="flex items-start">
                  <InformationCircleIcon className="w-6 h-6 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                  <div className="text-yellow-800 text-sm">
                    <p className="font-semibold mb-1">Penting:</p>
                    <ul className="space-y-1">
                      <li>• Pastikan bukti pembayaran jelas terbaca</li>
                      <li>• Screenshot atau foto struk pembayaran</li>
                      <li>• Format file: JPG, PNG, atau PDF</li>
                      <li>• Maksimal ukuran file: 10MB</li>
                    </ul>
                  </div>
                </div>
              </div>

              {!uploadedFile ? (
                <div className="file-upload-area">
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="payment-proof"
                  />
                  <label htmlFor="payment-proof" className="cursor-pointer">
                    <div className="text-center">
                      <DocumentArrowUpIcon className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p className="text-gray-600 mb-2">
                        Klik untuk upload bukti pembayaran
                      </p>
                      <p className="text-sm text-gray-500">
                        JPG, PNG, atau PDF (maksimal 10MB)
                      </p>
                    </div>
                  </label>
                </div>
              ) : (
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <CheckCircleIcon className="w-6 h-6 text-green-500 mr-2" />
                      <span className="font-medium">{uploadedFile.name}</span>
                      <span className="text-sm text-gray-500 ml-2">
                        ({(uploadedFile.size / 1024 / 1024).toFixed(2)} MB)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={removeFile}
                      className="text-red-500 hover:text-red-700"
                    >
                      Hapus
                    </button>
                  </div>
                  
                  {filePreview && (
                    <div className="mt-4">
                      <img
                        src={filePreview}
                        alt="Preview bukti pembayaran"
                        className="max-w-xs max-h-48 rounded-lg border"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Submit Button */}
            <div className="text-center">
              <button
                onClick={handleSubmit}
                disabled={loading || !selectedMethod || !uploadedFile}
                className="btn-primary px-12 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="flex items-center justify-center">
                    <div className="loading-spinner mr-2"></div>
                    Sedang mengupload...
                  </div>
                ) : (
                  'Kirim Bukti Pembayaran'
                )}
              </button>
            </div>

            {/* Contact Info */}
            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-2">Butuh Bantuan?</h4>
              <p className="text-blue-700 text-sm">
                Hubungi admin kami via WhatsApp:{' '}
                <a 
                  href="https://wa.me/6282274973133" 
                  className="font-semibold hover:underline"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  0822-7497-3133
                </a>
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      <ToastContainer position="top-right" />
    </>
  );
}