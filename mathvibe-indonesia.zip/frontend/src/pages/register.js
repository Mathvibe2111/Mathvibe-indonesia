import React, { useState } from 'react';
import Head from 'next/head';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { 
  UserIcon, 
  BuildingOffice2Icon, 
  EnvelopeIcon, 
  PhoneIcon, 
  MapPinIcon,
  CalendarDaysIcon,
  PhotoIcon,
  CheckCircleIcon
} from '@heroicons/react/24/outline';

export default function Register() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [filePreviews, setFilePreviews] = useState([]);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue
  } = useForm();

  const level = watch('level');

  const provinces = [
    'Aceh', 'Sumatera Utara', 'Sumatera Barat', 'Riau', 'Kepulauan Riau',
    'Jambi', 'Sumatera Selatan', 'Kepulauan Bangka Belitung', 'Bengkulu', 'Lampung',
    'Banten', 'DKI Jakarta', 'Jawa Barat', 'Jawa Tengah', 'DI Yogyakarta',
    'Jawa Timur', 'Kalimantan Barat', 'Kalimantan Tengah', 'Kalimantan Selatan',
    'Kalimantan Timur', 'Kalimantan Utara', 'Sulawesi Utara', 'Sulawesi Tengah',
    'Sulawesi Selatan', 'Sulawesi Tenggara', 'Sulawesi Barat', 'Gorontalo',
    'Maluku', 'Maluku Utara', 'Papua', 'Papua Barat', 'Nusa Tenggara Barat',
    'Nusa Tenggara Timur'
  ];

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    const maxFiles = 5;
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (files.length + uploadedFiles.length > maxFiles) {
      toast.error(`Maksimal ${maxFiles} file yang bisa diupload`);
      return;
    }

    const validFiles = files.filter(file => {
      if (file.size > maxSize) {
        toast.error(`File ${file.name} melebihi ukuran maksimal 10MB`);
        return false;
      }
      if (!['image/jpeg', 'image/png', 'image/jpg'].includes(file.type)) {
        toast.error(`File ${file.name} harus berformat JPG, PNG, atau JPEG`);
        return false;
      }
      return true;
    });

    const newFiles = [...uploadedFiles, ...validFiles];
    setUploadedFiles(newFiles);

    // Create preview URLs
    const previews = validFiles.map(file => URL.createObjectURL(file));
    setFilePreviews([...filePreviews, ...previews]);

    // Update form value
    setValue('social_proof_files', newFiles);
  };

  const removeFile = (index) => {
    const newFiles = uploadedFiles.filter((_, i) => i !== index);
    const newPreviews = filePreviews.filter((_, i) => i !== index);
    
    setUploadedFiles(newFiles);
    setFilePreviews(newPreviews);
    setValue('social_proof_files', newFiles);
  };

  const onSubmit = async (data) => {
    if (uploadedFiles.length === 0) {
      toast.error('Bukti sosial media wajib diupload');
      return;
    }

    setLoading(true);

    try {
      // In a real application, you would upload files to your server
      // For this demo, we'll simulate the upload process
      const formData = new FormData();
      
      // Add form data
      Object.keys(data).forEach(key => {
        if (key !== 'social_proof_files') {
          formData.append(key, data[key]);
        }
      });

      // Add files
      uploadedFiles.forEach((file, index) => {
        formData.append(`file_${index}`, file);
      });

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));

      toast.success('Pendaftaran berhasil! Silakan cek email Anda.');
      
      // Redirect to payment page
      setTimeout(() => {
        router.push('/payment');
      }, 2000);

    } catch (error) {
      toast.error('Terjadi kesalahan saat pendaftaran');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Head>
        <title>Daftar - MathVibe Indonesia</title>
        <meta name="description" content="Formulir pendaftaran Olimpiade Matematika MathVibe Indonesia" />
      </Head>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container-custom max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="card"
          >
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold gradient-text mb-4">
                Pendaftaran MathVibe Indonesia
              </h1>
              <p className="text-gray-600">
                Isi formulir di bawah ini untuk mendaftar olimpiade matematika
              </p>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Personal Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="form-label">
                    <UserIcon className="w-4 h-4 inline mr-2" />
                    Nama Lengkap *
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    {...register('full_name', { required: 'Nama lengkap wajib diisi' })}
                    placeholder="Masukkan nama lengkap"
                  />
                  {errors.full_name && (
                    <p className="text-red-500 text-sm mt-1">{errors.full_name.message}</p>
                  )}
                </div>

                <div>
                  <label className="form-label">
                    <BuildingOffice2Icon className="w-4 h-4 inline mr-2" />
                    Nama Sekolah *
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    {...register('school_name', { required: 'Nama sekolah wajib diisi' })}
                    placeholder="Masukkan nama sekolah"
                  />
                  {errors.school_name && (
                    <p className="text-red-500 text-sm mt-1">{errors.school_name.message}</p>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="form-label">
                    <EnvelopeIcon className="w-4 h-4 inline mr-2" />
                    Email *
                  </label>
                  <input
                    type="email"
                    className="form-input"
                    {...register('email', { 
                      required: 'Email wajib diisi',
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: 'Email tidak valid'
                      }
                    })}
                    placeholder="Masukkan email aktif"
                  />
                  {errors.email && (
                    <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
                  )}
                </div>

                <div>
                  <label className="form-label">
                    <PhoneIcon className="w-4 h-4 inline mr-2" />
                    Nomor HP (WhatsApp) *
                  </label>
                  <input
                    type="tel"
                    className="form-input"
                    {...register('phone', { 
                      required: 'Nomor HP wajib diisi',
                      pattern: {
                        value: /^[0-9]{10,13}$/,
                        message: 'Nomor HP tidak valid'
                      }
                    })}
                    placeholder="081234567890"
                  />
                  {errors.phone && (
                    <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="form-label">
                    Jenjang Pendidikan *
                  </label>
                  <select
                    className="form-input"
                    {...register('level', { required: 'Jenjang pendidikan wajib dipilih' })}
                  >
                    <option value="">Pilih jenjang</option>
                    <option value="SMP">SMP</option>
                    <option value="SMA">SMA</option>
                  </select>
                  {errors.level && (
                    <p className="text-red-500 text-sm mt-1">{errors.level.message}</p>
                  )}
                </div>

                <div>
                  <label className="form-label">
                    <MapPinIcon className="w-4 h-4 inline mr-2" />
                    Provinsi *
                  </label>
                  <select
                    className="form-input"
                    {...register('province', { required: 'Provinsi wajib dipilih' })}
                  >
                    <option value="">Pilih provinsi</option>
                    {provinces.map(province => (
                      <option key={province} value={province}>{province}</option>
                    ))}
                  </select>
                  {errors.province && (
                    <p className="text-red-500 text-sm mt-1">{errors.province.message}</p>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="form-label">
                    <CalendarDaysIcon className="w-4 h-4 inline mr-2" />
                    Tanggal Lahir
                  </label>
                  <input
                    type="date"
                    className="form-input"
                    {...register('birth_date')}
                  />
                </div>

                <div>
                  <label className="form-label">
                    <MapPinIcon className="w-4 h-4 inline mr-2" />
                    Alamat (Opsional)
                  </label>
                  <input
                    type="text"
                    className="form-input"
                    {...register('address')}
                    placeholder="Masukkan alamat lengkap"
                  />
                </div>
              </div>

              {/* Social Proof Upload */}
              <div className="border-t pt-6">
                <h3 className="text-xl font-semibold mb-4 flex items-center">
                  <PhotoIcon className="w-6 h-6 mr-2" />
                  Bukti Syarat Media Sosial *
                </h3>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <h4 className="font-semibold text-blue-800 mb-2">Syarat yang harus dipenuhi:</h4>
                  <ul className="text-blue-700 text-sm space-y-1">
                    <li>• Follow Instagram <strong>@mathvibe.indonesia</strong></li>
                    <li>• Follow TikTok <strong>@mathvibe.id</strong></li>
                    <li>• Subscribe YouTube <strong>@mathvibe.id</strong></li>
                    <li>• Like, comment, dan mention 3 teman di postingan utama</li>
                    <li>• Share postingan di story Instagram pribadi</li>
                  </ul>
                </div>

                <div className="file-upload-area mb-4">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <div className="text-center">
                      <PhotoIcon className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p className="text-gray-600 mb-2">
                        Klik untuk upload screenshot bukti
                      </p>
                      <p className="text-sm text-gray-500">
                        Maksimal 5 file, format JPG/PNG, maksimal 10MB per file
                      </p>
                    </div>
                  </label>
                </div>

                {/* File Previews */}
                {filePreviews.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {filePreviews.map((preview, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={preview}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-24 object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {uploadedFiles.length === 0 && (
                  <p className="text-red-500 text-sm mt-2">
                    * Bukti sosial media wajib diupload
                  </p>
                )}
              </div>

              {/* Submit Button */}
              <div className="pt-6 border-t">
                <button
                  type="submit"
                  disabled={loading || uploadedFiles.length === 0}
                  className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <div className="flex items-center justify-center">
                      <div className="loading-spinner mr-2"></div>
                      Sedang memproses...
                    </div>
                  ) : (
                    'Daftar Sekarang'
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      </div>

      <ToastContainer position="top-right" />
    </>
  );
}