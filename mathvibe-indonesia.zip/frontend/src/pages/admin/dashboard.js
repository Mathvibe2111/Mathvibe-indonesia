import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import { toast, ToastContainer } from 'react-toastify';
import {
  UsersIcon,
  CurrencyDollarIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  EyeIcon,
  DocumentCheckIcon,
  FunnelIcon,
  MagnifyingGlassIcon,
  ArrowDownTrayIcon,
  ChartBarIcon,
  MapIcon,
  AcademicCapIcon
} from '@heroicons/react/24/outline';

export default function AdminDashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [participants, setParticipants] = useState([]);
  const [statistics, setStatistics] = useState({
    total_participants: 0,
    verified_payments: 0,
    pending_payments: 0,
    rejected_payments: 0,
    smp_participants: 0,
    sma_participants: 0
  });
  const [filters, setFilters] = useState({
    search: '',
    level: 'all',
    status: 'all'
 });
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedParticipant, setSelectedParticipant] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const itemsPerPage = 10;

  // Mock data for demonstration
  const mockParticipants = [
    {
      id: 1,
      full_name: 'Ahmad Fauzan',
      school_name: 'SMP Negeri 1 Jakarta',
      email: 'ahmad.fauzan@email.com',
      phone: '081234567890',
      level: 'SMP',
      province: 'DKI Jakarta',
      payment_status: 'verified',
      social_proof_status: 'verified',
      cbt_password: 'MVI-SMP-20241014-0001',
      score_preliminary: 75,
      status: 'completed',
      registration_date: '2024-10-14 10:30:00'
    },
    {
      id: 2,
      full_name: 'Siti Nurhaliza',
      school_name: 'SMA Negeri 2 Surabaya',
      email: 'siti.nurhaliza@email.com',
      phone: '082345678901',
      level: 'SMA',
      province: 'Jawa Timur',
      payment_status: 'pending',
      social_proof_status: 'verified',
      cbt_password: null,
      score_preliminary: 0,
      status: 'registered',
      registration_date: '2024-10-14 11:15:00'
    },
    {
      id: 3,
      full_name: 'Budi Santoso',
      school_name: 'SMP Negeri 3 Bandung',
      email: 'budi.santoso@email.com',
      phone: '083456789012',
      level: 'SMP',
      province: 'Jawa Barat',
      payment_status: 'verified',
      social_proof_status: 'verified',
      cbt_password: 'MVI-SMP-20241014-0003',
      score_preliminary: 90,
      status: 'completed',
      registration_date: '2024-10-14 09:45:00'
    },
    {
      id: 4,
      full_name: 'Dewi Lestari',
      school_name: 'SMA Negeri 4 Medan',
      email: 'dewi.lestari@email.com',
      phone: '084567890123',
      level: 'SMA',
      province: 'Sumatera Utara',
      payment_status: 'rejected',
      social_proof_status: 'pending',
      cbt_password: null,
      score_preliminary: 0,
      status: 'disqualified',
      registration_date: '2024-10-14 14:20:00'
    },
    {
      id: 5,
      full_name: 'Rizki Pratama',
      school_name: 'SMP Negeri 5 Semarang',
      email: 'rizki.pratama@email.com',
      phone: '085678901234',
      level: 'SMP',
      province: 'Jawa Tengah',
      payment_status: 'verified',
      social_proof_status: 'verified',
      cbt_password: 'MVI-SMP-20241014-0005',
      score_preliminary: 82,
      status: 'completed',
      registration_date: '2024-10-14 16:30:00'
    }
  ];

  useEffect(() => {
    // Simulate loading data
    setTimeout(() => {
      setParticipants(mockParticipants);
      setStatistics({
        total_participants: 250,
        verified_payments: 180,
        pending_payments: 45,
        rejected_payments: 25,
        smp_participants: 140,
        sma_participants: 110
      });
      setLoading(false);
    }, 1000);
  }, []);

  const filteredParticipants = participants.filter(participant => {
    const matchesSearch = !filters.search || 
      participant.full_name.toLowerCase().includes(filters.search.toLowerCase()) ||
      participant.email.toLowerCase().includes(filters.search.toLowerCase()) ||
      participant.school_name.toLowerCase().includes(filters.search.toLowerCase());
    
    const matchesLevel = filters.level === 'all' || participant.level === filters.level;
    const matchesStatus = filters.status === 'all' || participant.payment_status === filters.status;
    
    return matchesSearch && matchesLevel && matchesStatus;
  });

  const totalPages = Math.ceil(filteredParticipants.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentParticipants = filteredParticipants.slice(startIndex, startIndex + itemsPerPage);

  const getStatusBadge = (status) => {
    const styles = {
      verified: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      rejected: 'bg-red-100 text-red-800'
    };
    return styles[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusIcon = (status) => {
    const icons = {
      verified: CheckCircleIcon,
      pending: ClockIcon,
      rejected: XCircleIcon
    };
    return icons[status] || ClockIcon;
  };

  const handleVerifyPayment = async (participantId, action) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success(
        action === 'verify' 
          ? 'Pembayaran berhasil diverifikasi' 
          : 'Pembayaran ditolak'
      );
      
      // Update participant status
      setParticipants(prev => 
        prev.map(p => 
          p.id === participantId 
            ? { ...p, payment_status: action === 'verify' ? 'verified' : 'rejected' }
            : p
        )
      );
      
      setShowModal(false);
      setSelectedParticipant(null);
    } catch (error) {
      toast.error('Terjadi kesalahan saat verifikasi');
    }
  };

  const handleExportExcel = () => {
    toast.success('Data berhasil diekspor ke Excel');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-spinner"></div>
      </div>
    );
  }

  return (
    <>
      <Head>
        <title>Dashboard Admin - MathVibe Indonesia</title>
      </Head>

      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="container-custom py-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold gradient-text">Dashboard Admin</h1>
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleExportExcel}
                  className="btn-outline"
                >
                  <ArrowDownTrayIcon className="w-5 h-5 inline mr-2" />
                  Export Excel
                </button>
                <button
                  onClick={() => router.push('/')}
                  className="text-gray-600 hover:text-gray-800"
                >
                  Kembali ke Home
                </button>
              </div>
            </div>
          </div>
        </header>

        <div className="container-custom py-8">
          {/* Statistics Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="card"
            >
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                  <UsersIcon className="w-8 h-8" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Peserta</p>
                  <p className="text-2xl font-bold text-gray-900">{statistics.total_participants}</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="card"
            >
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-green-100 text-green-600">
                  <CheckCircleIcon className="w-8 h-8" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Terverifikasi</p>
                  <p className="text-2xl font-bold text-gray-900">{statistics.verified_payments}</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="card"
            >
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-yellow-100 text-yellow-600">
                  <ClockIcon className="w-8 h-8" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Menunggu</p>
                  <p className="text-2xl font-bold text-gray-900">{statistics.pending_payments}</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="card"
            >
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-red-100 text-red-600">
                  <XCircleIcon className="w-8 h-8" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Ditolak</p>
                  <p className="text-2xl font-bold text-gray-900">{statistics.rejected_payments}</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Level Statistics */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="card"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <AcademicCapIcon className="w-8 h-8 text-primary-600" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Peserta SMP</p>
                    <p className="text-2xl font-bold text-gray-900">{statistics.smp_participants}</p>
                  </div>
                </div>
                <div className="text-3xl">📚</div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="card"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <AcademicCapIcon className="w-8 h-8 text-secondary-600" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Peserta SMA</p>
                    <p className="text-2xl font-bold text-gray-900">{statistics.sma_participants}</p>
                  </div>
                </div>
                <div className="text-3xl">🎓</div>
              </div>
            </motion.div>
          </div>

          {/* Filters */}
          <div className="card mb-6">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex-1 min-w-64">
                <label className="form-label">Cari Peserta</label>
                <div className="relative">
                  <MagnifyingGlassIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                  <input
                    type="text"
                    className="form-input pl-10"
                    placeholder="Nama, email, atau sekolah"
                    value={filters.search}
                    onChange={(e) => {
                      setFilters({ ...filters, search: e.target.value });
                      setCurrentPage(1);
                    }}
                  />
                </div>
              </div>
              
              <div>
                <label className="form-label">Jenjang</label>
                <select
                  className="form-input"
                  value={filters.level}
                  onChange={(e) => {
                    setFilters({ ...filters, level: e.target.value });
                    setCurrentPage(1);
                  }}
                >
                  <option value="all">Semua</option>
                  <option value="SMP">SMP</option>
                  <option value="SMA">SMA</option>
                </select>
              </div>
              
              <div>
                <label className="form-label">Status Pembayaran</label>
                <select
                  className="form-input"
                  value={filters.status}
                  onChange={(e) => {
                    setFilters({ ...filters, status: e.target.value });
                    setCurrentPage(1);
                  }}
                >
                  <option value="all">Semua</option>
                  <option value="verified">Terverifikasi</option>
                  <option value="pending">Menunggu</option>
                  <option value="rejected">Ditolak</option>
                </select>
              </div>
            </div>
          </div>

          {/* Participants Table */}
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="table-custom">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Sekolah</th>
                    <th>Jenjang</th>
                    <th>Provinsi</th>
                    <th>Status Bayar</th>
                    <th>Status Sosial</th>
                    <th>Skor</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {currentParticipants.map((participant, index) => {
                    const StatusIcon = getStatusIcon(participant.payment_status);
                    return (
                      <tr key={participant.id}>
                        <td>{startIndex + index + 1}</td>
                        <td>
                          <div>
                            <div className="font-medium">{participant.full_name}</div>
                            <div className="text-sm text-gray-500">{participant.email}</div>
                          </div>
                        </td>
                        <td>{participant.school_name}</td>
                        <td>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            participant.level === 'SMP' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'
                          }`}>
                            {participant.level}
                          </span>
                        </td>
                        <td>{participant.province}</td>
                        <td>
                          <div className="flex items-center">
                            <StatusIcon className={`w-4 h-4 mr-1 ${getStatusBadge(participant.payment_status).split(' ')[1]}`} />
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(participant.payment_status)}`}>
                              {participant.payment_status}
                            </span>
                          </div>
                        </td>
                        <td>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(participant.social_proof_status)}`}>
                            {participant.social_proof_status}
                          </span>
                        </td>
                        <td>
                          {participant.score_preliminary > 0 ? (
                            <span className="font-medium">{participant.score_preliminary}</span>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </td>
                        <td>
                          <div className="flex space-x-2">
                            <button
                              onClick={() => {
                                setSelectedParticipant(participant);
                                setShowModal(true);
                              }}
                              className="text-primary-600 hover:text-primary-800"
                              title="Lihat Detail"
                            >
                              <EyeIcon className="w-5 h-5" />
                            </button>
                            {participant.payment_status === 'pending' && (
                              <button
                                onClick={() => {
                                  setSelectedParticipant(participant);
                                  setShowModal(true);
                                }}
                                className="text-green-600 hover:text-green-800"
                                title="Verifikasi"
                              >
                                <DocumentCheckIcon className="w-5 h-5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between p-4 border-t">
                <div className="text-sm text-gray-700">
                  Menampilkan {startIndex + 1} sampai {Math.min(startIndex + itemsPerPage, filteredParticipants.length)} dari {filteredParticipants.length} peserta
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-1 border rounded disabled:opacity-50"
                  >
                    Sebelumnya
                  </button>
                  <span className="px-3 py-1 bg-primary-100 text-primary-800 rounded">
                    {currentPage} / {totalPages}
                  </span>
                  <button
                    onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 border rounded disabled:opacity-50"
                  >
                    Selanjutnya
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal */}
      {showModal && selectedParticipant && (
        <div className="modal-overlay">
          <div className="modal-content max-w-2xl max-h-screen overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">Detail Peserta</h3>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setSelectedParticipant(null);
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ×
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="font-medium text-gray-700">Nama Lengkap</label>
                  <p className="mt-1">{selectedParticipant.full_name}</p>
                </div>
                
                <div>
                  <label className="font-medium text-gray-700">Email</label>
                  <p className="mt-1">{selectedParticipant.email}</p>
                </div>
                
                <div>
                  <label className="font-medium text-gray-700">Sekolah</label>
                  <p className="mt-1">{selectedParticipant.school_name}</p>
                </div>
                
                <div>
                  <label className="font-medium text-gray-700">Jenjang</label>
                  <p className="mt-1">{selectedParticipant.level}</p>
                </div>
                
                <div>
                  <label className="font-medium text-gray-700">Provinsi</label>
                  <p className="mt-1">{selectedParticipant.province}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="font-medium text-gray-700">Status Pembayaran</label>
                    <p className="mt-1">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(selectedParticipant.payment_status)}`}>
                        {selectedParticipant.payment_status}
                      </span>
                    </p>
                  </div>
                  
                  <div>
                    <label className="font-medium text-gray-700">Status Sosial</label>
                    <p className="mt-1">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(selectedParticipant.social_proof_status)}`}>
                        {selectedParticipant.social_proof_status}
                      </span>
                    </p>
                  </div>
                </div>

                {selectedParticipant.cbt_password && (
                  <div>
                    <label className="font-medium text-gray-700">Password CBT</label>
                    <p className="mt-1 font-mono bg-gray-100 p-2 rounded">
                      {selectedParticipant.cbt_password}
                    </p>
                  </div>
                )}

                {selectedParticipant.payment_status === 'pending' && (
                  <div className="flex space-x-3 pt-4 border-t">
                    <button
                      onClick={() => handleVerifyPayment(selectedParticipant.id, 'verify')}
                      className="btn-primary flex-1"
                    >
                      <CheckCircleIcon className="w-5 h-5 inline mr-2" />
                      Verifikasi Pembayaran
                    </button>
                    <button
                      onClick={() => handleVerifyPayment(selectedParticipant.id, 'reject')}
                      className="btn-outline border-red-500 text-red-500 hover:bg-red-500 flex-1"
                    >
                      <XCircleIcon className="w-5 h-5 inline mr-2" />
                      Tolak Pembayaran
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      <ToastContainer position="top-right" />
    </>
  );
}