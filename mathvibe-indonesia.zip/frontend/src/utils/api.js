import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Add auth token if available
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('auth_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// API functions
export const authAPI = {
  login: (credentials) => api.post('/auth/admin/login', credentials),
  cbtLogin: (credentials) => api.post('/auth/cbt/login', credentials),
  logout: () => api.post('/auth/logout'),
  getCurrentUser: () => api.get('/auth/me'),
};

export const participantAPI = {
  register: (data) => api.post('/participants/register', data),
  getParticipants: (params) => api.get('/participants', { params }),
  getParticipant: (id) => api.get(`/participants/${id}`),
  verifyPayment: (id, action) => api.put(`/participants/${id}/verify-payment`, action),
  verifySocial: (id, status) => api.put(`/participants/${id}/verify-social`, status),
  generatePassword: (id) => api.post(`/participants/${id}/generate-password`),
};

export const adminAPI = {
  getDashboard: () => api.get('/admin/dashboard'),
  exportParticipants: (params) => api.get('/admin/export-participants', { params, responseType: 'blob' }),
  getSettings: () => api.get('/admin/settings'),
  updateSettings: (data) => api.put('/admin/settings', data),
};

export const cbtAPI = {
  startExam: () => api.post('/cbt/start-exam'),
  submitAnswer: (data) => api.post('/cbt/submit-answer', data),
  finishExam: (data) => api.post('/cbt/finish-exam', data),
  getResults: () => api.get('/cbt/results'),
  getLeaderboard: (params) => api.get('/cbt/leaderboard', { params }),
};

export const uploadAPI = {
  uploadSocialProof: (formData) => api.post('/upload/social-proof', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  uploadPaymentProof: (formData) => api.post('/upload/payment-proof', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  getFile: (filename) => `${API_URL}/upload/file/${filename}`,
};

export const statisticsAPI = {
  getPublicStats: () => api.get('/statistics/public'),
  getAdminStats: () => api.get('/statistics/admin'),
  getLeaderboard: (params) => api.get('/statistics/leaderboard', { params }),
};

export default api;