-- MathVibe Indonesia Database Schema
-- Created for MathVibe Indonesia Olympiad System

-- Create database
CREATE DATABASE IF NOT EXISTS mathvibe_indonesia;
USE mathvibe_indonesia;

-- Table for participants
CREATE TABLE participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    school_name VARCHAR(150) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    level ENUM('SMP', 'SMA') NOT NULL,
    birth_date DATE,
    address TEXT,
    social_proof_urls JSON,
    payment_proof_url VARCHAR(255),
    payment_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    social_proof_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    cbt_password VARCHAR(20),
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('registered', 'active', 'disqualified', 'completed') DEFAULT 'registered',
    score_preliminary INT DEFAULT 0,
    score_final INT DEFAULT 0,
    total_score INT DEFAULT 0,
    rank_preliminary INT DEFAULT 0,
    rank_final INT DEFAULT 0,
    final_participant BOOLEAN DEFAULT FALSE,
    province VARCHAR(50),
    INDEX idx_email (email),
    INDEX idx_payment_status (payment_status),
    INDEX idx_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for questions
CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    level ENUM('SMP', 'SMA') NOT NULL,
    question_text TEXT NOT NULL,
    options JSON,
    correct_answer VARCHAR(50) NOT NULL,
    question_type ENUM('multiple_choice', 'numeric') DEFAULT 'multiple_choice',
    points_correct INT DEFAULT 3,
    points_wrong INT DEFAULT -1,
    points_blank INT DEFAULT 0,
    time_limit INT DEFAULT 0,
    category VARCHAR(50),
    difficulty ENUM('easy', 'medium', 'hard') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_level (level),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for exam sessions
CREATE TABLE exam_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    participant_id INT NOT NULL,
    level ENUM('SMP', 'SMA') NOT NULL,
    session_type ENUM('preliminary', 'final') NOT NULL,
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP NULL,
    duration INT NOT NULL,
    status ENUM('active', 'completed', 'interrupted') DEFAULT 'active',
    total_score INT DEFAULT 0,
    FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE,
    INDEX idx_participant (participant_id),
    INDEX idx_session_type (session_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for participant answers
CREATE TABLE participant_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    question_id INT NOT NULL,
    participant_id INT NOT NULL,
    answer VARCHAR(255),
    is_correct BOOLEAN DEFAULT FALSE,
    points_earned INT DEFAULT 0,
    time_spent INT DEFAULT 0,
    answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES exam_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE,
    INDEX idx_session (session_id),
    INDEX idx_question (question_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for admins
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('superadmin', 'validator') DEFAULT 'validator',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for activity logs
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT,
    participant_id INT,
    action_type VARCHAR(50) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL,
    FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE,
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for system settings
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    participant_id INT NOT NULL,
    type ENUM('email', 'whatsapp') NOT NULL,
    subject VARCHAR(255),
    content TEXT,
    status ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
    sent_at TIMESTAMP NULL,
    error_message TEXT,
    FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_participant (participant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin
INSERT INTO admins (name, email, password_hash, role) VALUES 
('Super Admin', 'admin@mathvibe.id', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'superadmin');

-- Insert system settings
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('registration_start', '2024-10-19', 'Tanggal mulai pendaftaran'),
('registration_end', '2024-11-09', 'Tanggal berakhir pendaftaran'),
('preliminary_start', '2024-11-16', 'Tanggal mulai penyisihan'),
('preliminary_end', '2024-11-20', 'Tanggal berakhir penyisihan'),
('final_date', '2024-11-25', 'Tanggal final'),
('announcement_date', '2024-11-27', 'Tanggal pengumuman'),
('registration_fee', '30000', 'Biaya pendaftaran'),
('total_prize', '5500000', 'Total hadiah'),
('dana_number', '082274973133', 'Nomor DANA'),
('bri_number', '0323-01-009069-53-8', 'Nomor BRI'),
('admin_phone', '082274973133', 'Nomor admin'),
('instagram_handle', '@mathvibe.indonesia', 'Instagram MathVibe'),
('tiktok_handle', 'mathvibe.id', 'TikTok MathVibe'),
('youtube_handle', 'mathvibe.id', 'YouTube MathVibe');

-- Insert sample participants
INSERT INTO participants (full_name, school_name, email, phone, level, province, payment_status, social_proof_status, score_preliminary, status) VALUES
('Ahmad Fauzan', 'SMP Negeri 1 Jakarta', 'ahmad.fauzan@email.com', '081234567890', 'SMP', 'DKI Jakarta', 'verified', 'verified', 75, 'completed'),
('Siti Nurhaliza', 'SMA Negeri 2 Surabaya', 'siti.nurhaliza@email.com', '082345678901', 'SMA', 'Jawa Timur', 'verified', 'verified', 85, 'completed'),
('Budi Santoso', 'SMP Negeri 3 Bandung', 'budi.santoso@email.com', '083456789012', 'SMP', 'Jawa Barat', 'verified', 'verified', 90, 'completed'),
('Dewi Lestari', 'SMA Negeri 4 Medan', 'dewi.lestari@email.com', '084567890123', 'SMA', 'Sumatera Utara', 'verified', 'verified', 78, 'completed'),
('Rizki Pratama', 'SMP Negeri 5 Semarang', 'rizki.pratama@email.com', '085678901234', 'SMP', 'Jawa Tengah', 'verified', 'verified', 82, 'completed');

-- Insert sample questions for SMP
INSERT INTO questions (level, question_text, options, correct_answer, question_type, category, difficulty) VALUES
('SMP', 'Berapa hasil dari 15 × 12?', '["180", "160", "140", "120"]', '180', 'multiple_choice', 'Perkalian', 'easy'),
('SMP', 'Jumlah deret 2, 4, 6, ..., 100 adalah?', '["2550", "2500", "2450", "2400"]', '2550', 'multiple_choice', 'Deret Aritmatika', 'medium'),
('SMP', 'Berapa 3/4 dari 80?', '["60", "70", "75", "65"]', '60', 'multiple_choice', 'Pecahan', 'easy'),
('SMP', 'Persentase 25 dari 200 adalah?', '["12.5%", "15%", "20%", "25%"]', '12.5%', 'multiple_choice', 'Persentase', 'medium'),
('SMP', 'Hasil dari 2^5 adalah?', '["32", "64", "16", "128"]', '32', 'multiple_choice', 'Perpangkatan', 'easy');

-- Insert sample questions for SMA
INSERT INTO questions (level, question_text, options, correct_answer, question_type, category, difficulty) VALUES
('SMA', 'Jika log₂(x) = 5, maka x = ?', '["32", "64", "16", "128"]', '32', 'multiple_choice', 'Logaritma', 'medium'),
('SMA', 'Berapa suku ke-10 dari barisan 3, 7, 11, 15, ...?', '["39", "43", "47", "51"]', '39', 'multiple_choice', 'Barisan Aritmatika', 'medium'),
('SMA', 'Limit (x² - 1)/(x - 1) saat x→1 adalah?', '["2", "1", "0", "Tidak ada"]', '2', 'multiple_choice', 'Limit', 'hard'),
('SMA', 'Integral dari 2x dx adalah?', '["x² + C", "2x + C", "x + C", "2 + C"]', 'x² + C', 'multiple_choice', 'Integral', 'medium'),
('SMA', 'Turunan pertama dari f(x) = x³ adalah?', '["3x²", "x²", "3x", "x³"]', '3x²', 'multiple_choice', 'Turunan', 'medium');

-- Create view for statistics
CREATE VIEW statistics AS
SELECT 
    (SELECT COUNT(*) FROM participants) as total_registered,
    (SELECT COUNT(*) FROM participants WHERE payment_status = 'verified') as total_paid,
    (SELECT COUNT(DISTINCT province) FROM participants) as total_provinces,
    (SELECT setting_value FROM system_settings WHERE setting_key = 'total_prize') as total_prize;

-- Create view for leaderboard
CREATE VIEW leaderboard AS
SELECT 
    p.id,
    p.full_name,
    p.school_name,
    p.level,
    p.province,
    p.score_preliminary,
    p.score_final,
    p.total_score,
    p.rank_preliminary,
    p.rank_final,
    p.status,
    RANK() OVER (ORDER BY p.total_score DESC, p.score_final DESC) as global_rank
FROM participants p
WHERE p.payment_status = 'verified' AND p.status != 'disqualified'
ORDER BY p.total_score DESC, p.score_final DESC;