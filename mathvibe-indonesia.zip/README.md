# MathVibe Indonesia - Olimpiade Matematika Nasional

## 🎯 Tentang Project

MathVibe Indonesia adalah sistem web olimpiade matematika lengkap yang dirancang untuk kompetisi nasional dengan tagline **"Balapan Angka, Asah Logika!"**. Sistem ini mencakup landing page, pendaftaran online, sistem pembayaran, dashboard admin, dan platform CBT (Computer Based Test) yang terintegrasi.

## ✨ Fitur Utama

### 🌐 Landing Page
- Desain modern dan responsif
- Statistik real-time peserta
- Informasi lengkap kompetisi
- Integrasi media sosial

### 📝 Sistem Pendaftaran
- Formulir pendaftaran online
- Upload bukti syarat media sosial
- Validasi file dan ukuran
- Konfirmasi otomatis via email

### 💳 Sistem Pembayaran
- Multiple payment methods (DANA & Bank BRI)
- Upload bukti pembayaran
- Visual diskon launching
- Status tracking real-time

### 🛠️ Dashboard Admin
- Login admin terproteksi
- Manajemen peserta lengkap
- Validasi pembayaran
- Generate password CBT otomatis
- Export data ke Excel
- Statistik dan analytics

### 🖥️ Sistem CBT
- Login dengan password unik
- Timer otomatis per soal
- Anti-cheating system
- Random soal per peserta
- Auto-submit saat waktu habis

### 📊 Fitur Tambahan
- Sistem notifikasi email
- Integrasi WhatsApp
- Export data peserta
- Leaderboard real-time
- Sertifikat otomatis

## 🏗️ Teknologi yang Digunakan

### Backend
- **Node.js** dengan Express.js
- **MySQL** untuk database
- **JWT** untuk autentikasi
- **Multer** untuk file upload
- **Nodemailer** untuk email
- **Socket.io** untuk real-time

### Frontend
- **Next.js** (React Framework)
- **Tailwind CSS** untuk styling
- **Framer Motion** untuk animasi
- **React Hook Form** untuk form handling
- **Axios** untuk HTTP requests
- **React Query** untuk data fetching

### Database
- **MySQL** dengan struktur teroptimasi
- **Redis** untuk caching (opsional)
- **Migrations** untuk version control

## 📁 Struktur Project

```
mathvibe-indonesia/
├── backend/                 # API Server
│   ├── config/             # Database & app config
│   ├── routes/             # API endpoints
│   ├── utils/              # Helper functions
│   ├── middleware/         # Custom middleware
│   └── server.js           # Main server file
├── frontend/               # Next.js Application
│   ├── src/
│   │   ├── pages/          # Next.js pages
│   │   ├── components/     # Reusable components
│   │   ├── styles/         # CSS & styling
│   │   └── utils/          # Frontend utilities
│   ├── public/             # Static assets
│   └── next.config.js      # Next.js configuration
├── database/               # Database files
│   ├── schema.sql          # Database schema
│   └── seed.sql            # Sample data
├── docs/                   # Documentation
└── README.md              # This file
```

## 🚀 Cara Install & Menjalankan

### Prerequisites
- Node.js (v14 atau lebih baru)
- MySQL (v5.7 atau lebih baru)
- NPM atau Yarn

### 1. Clone Repository
```bash
git clone https://github.com/your-username/mathvibe-indonesia.git
cd mathvibe-indonesia
```

### 2. Setup Database
```bash
# Import database schema
mysql -u root -p mathvibe_indonesia < database/schema.sql

# Import sample data (optional)
mysql -u root -p mathvibe_indonesia < database/seed.sql
```

### 3. Install Dependencies

#### Backend
```bash
cd backend
npm install
```

#### Frontend
```bash
cd frontend
npm install
```

### 4. Environment Configuration

#### Backend (.env)
```env
# Database
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=mathvibe_indonesia
DB_PORT=3306

# Server
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:3000

# JWT
JWT_SECRET=your-super-secret-jwt-key
JWT_EXPIRE=7d

# Email (Gmail SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
FROM_EMAIL=admin@mathvibe.id

# Payment
DANA_NUMBER=082274973133
BRI_NUMBER=0323-01-009069-53-8
ADMIN_PHONE=082274973133

# Social Media
INSTAGRAM_HANDLE=@mathvibe.indonesia
TIKTOK_HANDLE=mathvibe.id
YOUTUBE_HANDLE=mathvibe.id
```

#### Frontend (.env.local)
```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api
NEXT_PUBLIC_DANA_NUMBER=082274973133
NEXT_PUBLIC_BRI_NUMBER=0323-01-009069-53-8
NEXT_PUBLIC_ADMIN_PHONE=082274973133
```

### 5. Menjalankan Aplikasi

#### Development Mode

**Backend:**
```bash
cd backend
npm run dev
# atau
npm start
```

**Frontend:**
```bash
cd frontend
npm run dev
```

Aplikasi akan berjalan di:
- Frontend: http://localhost:3000
- Backend: http://localhost:5000

#### Production Mode

**Build Frontend:**
```bash
cd frontend
npm run build
npm run start
```

**Backend Production:**
```bash
cd backend
NODE_ENV=production npm start
```

## 👤 Default Login

### Admin Dashboard
- **URL:** http://localhost:3000/admin/dashboard
- **Email:** admin@mathvibe.id
- **Password:** Mathvibe2025

### Demo Peserta CBT
- **Email:** ahmad.fauzan@email.com
- **Password CBT:** MVI-SMP-20241014-0001

## 📱 Fitur Demo

### Landing Page
- Statistik peserta real-time
- Informasi kompetisi lengkap
- Sistem pendaftaran terintegrasi

### Dashboard Admin
- Manajemen peserta lengkap
- Validasi pembayaran
- Export data ke Excel
- Monitoring real-time

### Sistem CBT
- Login dengan password unik
- Timer otomatis
- Anti-cheating system
- Hasil otomatis

## 🔧 Konfigurasi Tambahan

### Email Setup (Gmail)
1. Aktifkan 2FA di akun Gmail
2. Generate App Password
3. Masukkan di environment variable SMTP_PASS

### File Upload
- File disimpan di folder `backend/uploads/`
- Maksimal ukuran file: 10MB
- Format yang diizinkan: JPG, PNG, PDF

### Database Optimization
```sql
-- Tambahkan index untuk performa
CREATE INDEX idx_participants_email ON participants(email);
CREATE INDEX idx_participants_payment ON participants(payment_status);
CREATE INDEX idx_questions_level ON questions(level);
```

## 🚀 Deployment

### Vercel (Frontend)
1. Push code ke GitHub
2. Hubungkan dengan Vercel
3. Set environment variables
4. Deploy

### Server (Backend)
1. Install dependencies di server
2. Setup PM2 untuk process management
3. Configure reverse proxy (Nginx)
4. Setup SSL certificate

### Contoh Nginx Config
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📊 Monitoring & Maintenance

### Health Check
```bash
# Check server status
curl http://localhost:5000/api/health

# Check database connection
mysql -u root -p -e "SELECT 1"
```

### Backup Database
```bash
# Backup database
mysqldump -u root -p mathvibe_indonesia > backup_$(date +%Y%m%d).sql

# Restore database
mysql -u root -p mathvibe_indonesia < backup_file.sql
```

## 🔒 Security Features

- JWT Authentication
- Input Validation & Sanitization
- SQL Injection Prevention
- XSS Protection
- Rate Limiting
- File Upload Security
- HTTPS Enforcement

## 📈 Performance Optimization

- Database Indexing
- Image Compression
- Lazy Loading
- Code Splitting
- Caching Strategy
- CDN Integration (optional)

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check MySQL service status
   - Verify credentials in .env
   - Check firewall settings

2. **Email Not Sending**
   - Verify SMTP credentials
   - Check Gmail App Password
   - Enable less secure apps (deprecated)

3. **File Upload Error**
   - Check folder permissions
   - Verify upload limit in nginx/php.ini
   - Check disk space

4. **CORS Error**
   - Verify FRONTEND_URL in backend .env
   - Check CORS configuration
   - Ensure same protocol (http/https)

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Support

Untuk bantuan dan pertanyaan:
- WhatsApp: 0822-7497-3133
- Email: admin@mathvibe.id
- Instagram: @mathvibe.indonesia

## 🙏 Acknowledgments

- Tim pengembang MathVibe Indonesia
- Kontributor open source
- Komunitas matematika Indonesia

---

**MathVibe Indonesia** - *Balapan Angka, Asah Logika!* 🧮✨