const { query } = require('../config/database');

const seedData = async () => {
    try {
        console.log('Seeding database...');

        // Insert sample participants
        await query(`
            INSERT INTO participants (full_name, school_name, email, phone, level, province, payment_status, social_proof_status, score_preliminary, status) VALUES
            ('Ahmad Fauzan', 'SMP Negeri 1 Jakarta', 'ahmad.fauzan@email.com', '081234567890', 'SMP', 'DKI Jakarta', 'verified', 'verified', 75, 'completed'),
            ('Siti Nurhaliza', 'SMA Negeri 2 Surabaya', 'siti.nurhaliza@email.com', '082345678901', 'SMA', 'Jawa Timur', 'verified', 'verified', 85, 'completed'),
            ('Budi Santoso', 'SMP Negeri 3 Bandung', 'budi.santoso@email.com', '083456789012', 'SMP', 'Jawa Barat', 'verified', 'verified', 90, 'completed'),
            ('Dewi Lestari', 'SMA Negeri 4 Medan', 'dewi.lestari@email.com', '084567890123', 'SMA', 'Sumatera Utara', 'verified', 'verified', 78, 'completed'),
            ('Rizki Pratama', 'SMP Negeri 5 Semarang', 'rizki.pratama@email.com', '085678901234', 'SMP', 'Jawa Tengah', 'verified', 'verified', 82, 'completed')
        `);

        // Insert sample questions for SMP
        await query(`
            INSERT INTO questions (level, question_text, options, correct_answer, question_type, category, difficulty) VALUES
            ('SMP', 'Berapa hasil dari 15 × 12?', '["180", "160", "140", "120"]', '180', 'multiple_choice', 'Perkalian', 'easy'),
            ('SMP', 'Jumlah deret 2, 4, 6, ..., 100 adalah?', '["2550", "2500", "2450", "2400"]', '2550', 'multiple_choice', 'Deret Aritmatika', 'medium'),
            ('SMP', 'Berapa 3/4 dari 80?', '["60", "70", "75", "65"]', '60', 'multiple_choice', 'Pecahan', 'easy'),
            ('SMP', 'Persentase 25 dari 200 adalah?', '["12.5%", "15%", "20%", "25%"]', '12.5%', 'multiple_choice', 'Persentase', 'medium'),
            ('SMP', 'Hasil dari 2^5 adalah?', '["32", "64", "16", "128"]', '32', 'multiple_choice', 'Perpangkatan', 'easy')
        `);

        // Insert sample questions for SMA
        await query(`
            INSERT INTO questions (level, question_text, options, correct_answer, question_type, category, difficulty) VALUES
            ('SMA', 'Jika log₂(x) = 5, maka x = ?', '["32", "64", "16", "128"]', '32', 'multiple_choice', 'Logaritma', 'medium'),
            ('SMA', 'Berapa suku ke-10 dari barisan 3, 7, 11, 15, ...?', '["39", "43", "47", "51"]', '39', 'multiple_choice', 'Barisan Aritmatika', 'medium'),
            ('SMA', 'Limit (x² - 1)/(x - 1) saat x→1 adalah?', '["2", "1", "0", "Tidak ada"]', '2', 'multiple_choice', 'Limit', 'hard'),
            ('SMA', 'Integral dari 2x dx adalah?', '["x² + C", "2x + C", "x + C", "2 + C"]', 'x² + C', 'multiple_choice', 'Integral', 'medium'),
            ('SMA', 'Turunan pertama dari f(x) = x³ adalah?', '["3x²", "x²", "3x", "x³"]', '3x²', 'multiple_choice', 'Turunan', 'medium')
        `);

        console.log('Database seeded successfully!');
        process.exit(0);

    } catch (error) {
        console.error('Seeding error:', error);
        process.exit(1);
    }
};

seedData();