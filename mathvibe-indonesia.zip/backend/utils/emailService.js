const nodemailer = require('nodemailer');

class EmailService {
    constructor() {
        this.transporter = nodemailer.createTransporter({
            host: process.env.SMTP_HOST || 'smtp.gmail.com',
            port: process.env.SMTP_PORT || 587,
            secure: false,
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
            }
        });
    }

    async sendRegistrationConfirmation(participant) {
        const mailOptions = {
            from: `"${process.env.FROM_NAME}" <${process.env.FROM_EMAIL}>`,
            to: participant.email,
            subject: 'Pendaftaran MathVibe Indonesia Berhasil',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #007BFF;">Selamat Bergabung di MathVibe Indonesia!</h2>
                    <p>Halo <strong>${participant.full_name}</strong>,</p>
                    <p>Terima kasih telah mendaftar di Olimpiade Matematika MathVibe Indonesia.</p>
                    
                    <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Detail Pendaftaran Anda:</h3>
                        <ul>
                            <li><strong>Nama:</strong> ${participant.full_name}</li>
                            <li><strong>Sekolah:</strong> ${participant.school_name}</li>
                            <li><strong>Jenjang:</strong> ${participant.level}</li>
                            <li><strong>Email:</strong> ${participant.email}</li>
                            <li><strong>No. HP:</strong> ${participant.phone}</li>
                        </ul>
                    </div>
                    
                    <p><strong>Selanjutnya:</strong></p>
                    <ol>
                        <li>Lakukan pembayaran sebesar Rp 30.000 ke rekening yang tersedia</li>
                        <li>Upload bukti pembayaran di dashboard peserta</li>
                        <li>Tunggu verifikasi dari admin (1-2 hari kerja)</li>
                        <li>Setelah terverifikasi, Anda akan menerima password untuk login ke sistem CBT</li>
                    </ol>
                    
                    <p>Untuk informasi lebih lanjut, hubungi admin kami di WhatsApp: ${process.env.ADMIN_PHONE}</p>
                    
                    <p style="color: #666; font-size: 12px;">
                        Salam,<br>
                        Tim MathVibe Indonesia<br>
                        <em>Balapan Angka, Asah Logika!</em>
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true, message: 'Email sent successfully' };
        } catch (error) {
            console.error('Error sending email:', error);
            return { success: false, message: error.message };
        }
    }

    async sendPaymentVerified(participant, cbtPassword) {
        const mailOptions = {
            from: `"${process.env.FROM_NAME}" <${process.env.FROM_EMAIL}>`,
            to: participant.email,
            subject: 'Verifikasi Pembayaran MathVibe Indonesia - Password CBT Anda',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #28a745;">Pembayaran Anda Telah Diverifikasi!</h2>
                    <p>Halo <strong>${participant.full_name}</strong>,</p>
                    <p>Selamat! Pembayaran Anda telah berhasil diverifikasi oleh admin kami.</p>
                    
                    <div style="background-color: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #c3e6cb;">
                        <h3>Password CBT Anda:</h3>
                        <div style="background-color: white; padding: 15px; border-radius: 5px; text-align: center; font-size: 24px; font-weight: bold; color: #007BFF; letter-spacing: 2px;">
                            ${cbtPassword}
                        </div>
                        <p style="color: #155724; font-size: 14px; margin-top: 10px;">
                            <strong>Simpan password ini dengan aman!</strong> Anda akan membutuhkannya untuk login ke sistem ujian.
                        </p>
                    </div>
                    
                    <h3>Jadwal Ujian:</h3>
                    <ul>
                        <li><strong>Babak Penyisihan:</strong> 16-20 November 2024</li>
                        <li><strong>Babak Final:</strong> 25 November 2024</li>
                        <li><strong>Pengumuman:</strong> 27 November 2024</li>
                    </ul>
                    
                    <p><strong>Link CBT:</strong> <a href="${process.env.FRONTEND_URL}/cbt" style="color: #007BFF;">${process.env.FRONTEND_URL}/cbt</a></p>
                    
                    <div style="background-color: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; border: 1px solid #ffeaa7;">
                        <h4 style="color: #856404;">Penting:</h4>
                        <ul style="color: #856404;">
                            <li>Pastikan koneksi internet stabil saat ujian</li>
                            <liGunakan browser yang direkomendasikan (Chrome/Firefox terbaru)</li>
                            <li>Matikan semua tab dan aplikasi lain selama ujian</li>
                            <li>Untuk babak final, kamera harus menyala</li>
                        </ul>
                    </div>
                    
                    <p>Semoga sukses dalam kompetisi!</p>
                    
                    <p style="color: #666; font-size: 12px;">
                        Salam,<br>
                        Tim MathVibe Indonesia<br>
                        <em>Balapan Angka, Asah Logika!</em>
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true, message: 'Email sent successfully' };
        } catch (error) {
            console.error('Error sending email:', error);
            return { success: false, message: error.message };
        }
    }

    async sendExamReminder(participant, examType, date, time) {
        const mailOptions = {
            from: `"${process.env.FROM_NAME}" <${process.env.FROM_EMAIL}>`,
            to: participant.email,
            subject: `Pengingat ${examType} MathVibe Indonesia`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #007BFF;">Pengingat ${examType}</h2>
                    <p>Halo <strong>${participant.full_name}</strong>,</p>
                    <p>Ini adalah pengingat untuk ${examType} MathVibe Indonesia yang akan segera dimulai.</p>
                    
                    <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h3>Detail ${examType}:</h3>
                        <ul>
                            <li><strong>Tanggal:</strong> ${date}</li>
                            <li><strong>Waktu:</strong> ${time}</li>
                            <li><strong>Jenjang:</strong> ${participant.level}</li>
                        </ul>
                    </div>
                    
                    <p><strong>Password CBT Anda:</strong> ${participant.cbt_password}</p>
                    <p><strong>Link CBT:</strong> <a href="${process.env.FRONTEND_URL}/cbt">${process.env.FRONTEND_URL}/cbt</a></p>
                    
                    <p>Semoga sukses!</p>
                    
                    <p style="color: #666; font-size: 12px;">
                        Salam,<br>
                        Tim MathVibe Indonesia
                    </p>
                </div>
            `
        };

        try {
            await this.transporter.sendMail(mailOptions);
            return { success: true, message: 'Email sent successfully' };
        } catch (error) {
            console.error('Error sending email:', error);
            return { success: false, message: error.message };
        }
    }
}

module.exports = new EmailService();