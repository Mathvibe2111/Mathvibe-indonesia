const express = require('express');
const { body, validationResult } = require('express-validator');
const { query } = require('../config/database');
const { verifyAdmin } = require('./auth');
const { generateCBTPassword } = require('../utils/generatePassword');
const emailService = require('../utils/emailService');
const XLSX = require('xlsx');
const router = express.Router();

// Dashboard statistics
router.get('/dashboard', verifyAdmin, async (req, res) => {
    try {
        const stats = await query(`
            SELECT 
                COUNT(*) as total_participants,
                SUM(CASE WHEN payment_status = 'verified' THEN 1 ELSE 0 END) as verified_payments,
                SUM(CASE WHEN payment_status = 'pending' THEN 1 ELSE 0 END) as pending_payments,
                SUM(CASE WHEN payment_status = 'rejected' THEN 1 ELSE 0 END) as rejected_payments,
                SUM(CASE WHEN level = 'SMP' THEN 1 ELSE 0 END) as smp_participants,
                SUM(CASE WHEN level = 'SMA' THEN 1 ELSE 0 END) as sma_participants,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_exams,
                SUM(CASE WHEN final_participant = TRUE THEN 1 ELSE 0 END) as final_participants
            FROM participants
        `);

        const recentParticipants = await query(`
            SELECT id, full_name, email, level, payment_status, registration_date
            FROM participants 
            ORDER BY registration_date DESC 
            LIMIT 10
        `);

        const dailyRegistrations = await query(`
            SELECT 
                DATE(registration_date) as date,
                COUNT(*) as registrations
            FROM participants 
            WHERE registration_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY DATE(registration_date)
            ORDER BY date DESC
        `);

        res.json({
            success: true,
            data: {
                overview: stats[0],
                recentParticipants,
                dailyRegistrations
            }
        });

    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil data dashboard'
        });
    }
});

// Get all participants with filters
router.get('/participants', verifyAdmin, async (req, res) => {
    try {
        const { 
            page = 1, 
            limit = 10, 
            search = '', 
            level = 'all', 
            status = 'all',
            payment_status = 'all'
        } = req.query;
        
        const offset = (page - 1) * limit;

        let whereClause = 'WHERE 1=1';
        let params = [];

        if (search) {
            whereClause += ' AND (p.full_name LIKE ? OR p.email LIKE ? OR p.school_name LIKE ?)';
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }

        if (level !== 'all') {
            whereClause += ' AND p.level = ?';
            params.push(level);
        }

        if (status !== 'all') {
            whereClause += ' AND p.status = ?';
            params.push(status);
        }

        if (payment_status !== 'all') {
            whereClause += ' AND p.payment_status = ?';
            params.push(payment_status);
        }

        const participants = await query(`
            SELECT 
                p.id, p.full_name, p.school_name, p.email, p.phone, p.level, p.province,
                p.payment_status, p.social_proof_status, p.cbt_password, p.status,
                p.score_preliminary, p.score_final, p.total_score, p.final_participant,
                p.registration_date, p.payment_proof_url
            FROM participants p
            ${whereClause}
            ORDER BY p.registration_date DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(limit), parseInt(offset)]);

        const totalCount = await query(`
            SELECT COUNT(*) as total FROM participants p ${whereClause}
        `, params);

        res.json({
            success: true,
            data: {
                participants,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: totalCount[0].total,
                    pages: Math.ceil(totalCount[0].total / limit)
                }
            }
        });

    } catch (error) {
        console.error('Get participants error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil data peserta'
        });
    }
});

// Get participant details
router.get('/participants/:id', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;

        const participants = await query(`
            SELECT 
                p.*,
                es.id as session_id, es.start_time, es.end_time, es.total_score as exam_score,
                COUNT(pa.id) as questions_answered
            FROM participants p
            LEFT JOIN exam_sessions es ON p.id = es.participant_id
            LEFT JOIN participant_answers pa ON es.id = pa.session_id
            WHERE p.id = ?
            GROUP BY p.id, es.id
        `, [id]);

        if (participants.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Peserta tidak ditemukan'
            });
        }

        // Get detailed answers if exam session exists
        let detailedAnswers = [];
        if (participants[0].session_id) {
            detailedAnswers = await query(`
                SELECT pa.*, q.question_text, q.correct_answer, q.explanation
                FROM participant_answers pa
                JOIN questions q ON pa.question_id = q.id
                WHERE pa.session_id = ?
                ORDER BY pa.answered_at
            `, [participants[0].session_id]);
        }

        res.json({
            success: true,
            data: {
                participant: participants[0],
                detailed_answers: detailedAnswers
            }
        });

    } catch (error) {
        console.error('Get participant details error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil detail peserta'
        });
    }
});

// Verify payment
router.put('/participants/:id/verify-payment', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { action, reason } = req.body; // action: 'verify' or 'reject'

        if (!['verify', 'reject'].includes(action)) {
            return res.status(400).json({
                success: false,
                message: 'Aksi tidak valid'
            });
        }

        // Get participant details
        const participants = await query(
            'SELECT * FROM participants WHERE id = ?',
            [id]
        );

        if (participants.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Peserta tidak ditemukan'
            });
        }

        const participant = participants[0];

        if (action === 'verify') {
            // Generate CBT password
            const cbtPassword = generateCBTPassword(participant.level, participant.id);
            
            // Update participant
            await query(
                'UPDATE participants SET payment_status = ?, cbt_password = ?, status = ? WHERE id = ?',
                ['verified', cbtPassword, 'active', id]
            );

            // Send email with CBT password
            try {
                await emailService.sendPaymentVerified({
                    full_name: participant.full_name,
                    email: participant.email,
                    level: participant.level,
                    cbt_password: cbtPassword
                }, cbtPassword);
            } catch (emailError) {
                console.error('Email sending error:', emailError);
            }

            // Log admin action
            await query(
                'INSERT INTO activity_logs (admin_id, participant_id, action_type, description) VALUES (?, ?, ?, ?)',
                [req.user.id, id, 'payment_verified', `Payment verified, CBT password: ${cbtPassword}`]
            );

            res.json({
                success: true,
                message: 'Pembayaran berhasil diverifikasi',
                data: { cbt_password: cbtPassword }
            });

        } else {
            // Reject payment
            await query(
                'UPDATE participants SET payment_status = ?, status = ? WHERE id = ?',
                ['rejected', 'disqualified', id]
            );

            // Log admin action
            await query(
                'INSERT INTO activity_logs (admin_id, participant_id, action_type, description) VALUES (?, ?, ?, ?)',
                [req.user.id, id, 'payment_rejected', `Payment rejected: ${reason || 'No reason provided'}`]
            );

            res.json({
                success: true,
                message: 'Pembayaran ditolak'
            });
        }

    } catch (error) {
        console.error('Verify payment error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat verifikasi pembayaran'
        });
    }
});

// Verify social proof
router.put('/participants/:id/verify-social', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body; // 'verified' or 'rejected'

        if (!['verified', 'rejected'].includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Status tidak valid'
            });
        }

        await query(
            'UPDATE participants SET social_proof_status = ? WHERE id = ?',
            [status, id]
        );

        // Log admin action
        await query(
            'INSERT INTO activity_logs (admin_id, participant_id, action_type, description) VALUES (?, ?, ?, ?)',
            [req.user.id, id, 'social_proof_verified', `Social proof ${status}`]
        );

        res.json({
            success: true,
            message: `Bukti sosial berhasil di${status === 'verified' ? 'verifikasi' : 'tolak'}`
        });

    } catch (error) {
        console.error('Verify social proof error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat verifikasi bukti sosial'
        });
    }
});

// Generate CBT password manually
router.post('/participants/:id/generate-password', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;

        const participants = await query(
            'SELECT * FROM participants WHERE id = ? AND payment_status = ?',
            [id, 'verified']
        );

        if (participants.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Peserta belum terverifikasi pembayarannya'
            });
        }

        const participant = participants[0];
        const cbtPassword = generateCBTPassword(participant.level, participant.id);

        await query(
            'UPDATE participants SET cbt_password = ? WHERE id = ?',
            [cbtPassword, id]
        );

        // Send email
        try {
            await emailService.sendPaymentVerified({
                full_name: participant.full_name,
                email: participant.email,
                level: participant.level,
                cbt_password: cbtPassword
            }, cbtPassword);
        } catch (emailError) {
            console.error('Email sending error:', emailError);
        }

        res.json({
            success: true,
            message: 'Password CBT berhasil digenerate',
            data: { cbt_password: cbtPassword }
        });

    } catch (error) {
        console.error('Generate password error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat generate password'
        });
    }
});

// Export participants to Excel
router.get('/export-participants', verifyAdmin, async (req, res) => {
    try {
        const { level = 'all', status = 'all' } = req.query;

        let whereClause = 'WHERE 1=1';
        let params = [];

        if (level !== 'all') {
            whereClause += ' AND level = ?';
            params.push(level);
        }

        if (status !== 'all') {
            whereClause += ' AND status = ?';
            params.push(status);
        }

        const participants = await query(`
            SELECT 
                id as 'ID',
                full_name as 'Nama Lengkap',
                school_name as 'Sekolah',
                email as 'Email',
                phone as 'No HP',
                level as 'Jenjang',
                province as 'Provinsi',
                payment_status as 'Status Pembayaran',
                social_proof_status as 'Status Sosial',
                cbt_password as 'Password CBT',
                score_preliminary as 'Skor Penyisihan',
                score_final as 'Skor Final',
                total_score as 'Total Skor',
                status as 'Status',
                DATE_FORMAT(registration_date, '%d/%m/%Y %H:%i') as 'Tanggal Daftar'
            FROM participants
            ${whereClause}
            ORDER BY total_score DESC, score_final DESC
        `, params);

        // Create workbook
        const workbook = XLSX.utils.book_new();
        const worksheet = XLSX.utils.json_to_sheet(participants);

        // Set column widths
        const columnWidths = [
            { wch: 5 },  // ID
            { wch: 25 }, // Nama Lengkap
            { wch: 30 }, // Sekolah
            { wch: 25 }, // Email
            { wch: 15 }, // No HP
            { wch: 10 }, // Jenjang
            { wch: 20 }, // Provinsi
            { wch: 15 }, // Status Pembayaran
            { wch: 15 }, // Status Sosial
            { wch: 20 }, // Password CBT
            { wch: 15 }, // Skor Penyisihan
            { wch: 15 }, // Skor Final
            { wch: 15 }, // Total Skor
            { wch: 15 }, // Status
            { wch: 20 }  // Tanggal Daftar
        ];
        worksheet['!cols'] = columnWidths;

        XLSX.utils.book_append_sheet(workbook, worksheet, 'Peserta');

        // Set response headers
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename=peserta_mathvibe_${Date.now()}.xlsx`);

        // Send file
        const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
        res.send(buffer);

    } catch (error) {
        console.error('Export participants error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat export data'
        });
    }
});

// System settings
router.get('/settings', verifyAdmin, async (req, res) => {
    try {
        const settings = await query('SELECT * FROM system_settings');
        
        const settingsObject = {};
        settings.forEach(setting => {
            settingsObject[setting.setting_key] = setting.setting_value;
        });

        res.json({
            success: true,
            data: settingsObject
        });

    } catch (error) {
        console.error('Get settings error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil pengaturan'
        });
    }
});

router.put('/settings', verifyAdmin, async (req, res) => {
    try {
        const { key, value } = req.body;

        await query(
            'UPDATE system_settings SET setting_value = ? WHERE setting_key = ?',
            [value, key]
        );

        res.json({
            success: true,
            message: 'Pengaturan berhasil diperbarui'
        });

    } catch (error) {
        console.error('Update settings error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat memperbarui pengaturan'
        });
    }
});

module.exports = router;