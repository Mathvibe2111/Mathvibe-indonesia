const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { query } = require('../config/database');
const router = express.Router();

// Admin login validation
const loginValidation = [
    body('email').isEmail().withMessage('Email tidak valid'),
    body('password').notEmpty().withMessage('Password wajib diisi')
];

// Admin login
router.post('/admin/login', loginValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validasi gagal',
                errors: errors.array()
            });
        }

        const { email, password } = req.body;

        // Find admin
        const admins = await query(
            'SELECT * FROM admins WHERE email = ? AND is_active = true',
            [email]
        );

        if (admins.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Email atau password salah'
            });
        }

        const admin = admins[0];

        // Verify password (for demo, we'll skip bcrypt verification)
        // In production, use: const isMatch = await bcrypt.compare(password, admin.password_hash);
        const isMatch = password === 'Mathvibe2025'; // Demo password

        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Email atau password salah'
            });
        }

        // Generate JWT token
        const token = jwt.sign(
            { 
                id: admin.id, 
                email: admin.email, 
                role: admin.role 
            },
            process.env.JWT_SECRET || 'default-secret-key',
            { expiresIn: process.env.JWT_EXPIRE || '7d' }
        );

        // Update last login
        await query(
            'UPDATE admins SET last_login = NOW() WHERE id = ?',
            [admin.id]
        );

        // Log admin login
        await query(
            'INSERT INTO activity_logs (admin_id, action_type, description, ip_address) VALUES (?, ?, ?, ?)',
            [admin.id, 'admin_login', 'Admin login successful', req.ip]
        );

        res.json({
            success: true,
            message: 'Login berhasil',
            data: {
                token,
                admin: {
                    id: admin.id,
                    name: admin.name,
                    email: admin.email,
                    role: admin.role
                }
            }
        });

    } catch (error) {
        console.error('Admin login error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat login'
        });
    }
});

// Admin logout
router.post('/admin/logout', async (req, res) => {
    try {
        // In a real application, you might want to invalidate the token
        // For now, we'll just return a success message
        res.json({
            success: true,
            message: 'Logout berhasil'
        });
    } catch (error) {
        console.error('Admin logout error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat logout'
        });
    }
});

// CBT login validation
const cbtLoginValidation = [
    body('email').isEmail().withMessage('Email tidak valid'),
    body('password').notEmpty().withMessage('Password CBT wajib diisi')
];

// CBT participant login
router.post('/cbt/login', cbtLoginValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validasi gagal',
                errors: errors.array()
            });
        }

        const { email, password } = req.body;

        // Find participant with verified payment
        const participants = await query(
            `SELECT * FROM participants 
             WHERE email = ? 
             AND payment_status = 'verified' 
             AND cbt_password = ?
             AND status != 'disqualified'`,
            [email, password]
        );

        if (participants.length === 0) {
            return res.status(401).json({
                success: false,
                message: 'Email atau password CBT salah, atau akun belum terverifikasi'
            });
        }

        const participant = participants[0];

        // Generate JWT token for CBT
        const token = jwt.sign(
            { 
                id: participant.id, 
                email: participant.email,
                level: participant.level,
                type: 'cbt_participant'
            },
            process.env.JWT_SECRET || 'default-secret-key',
            { expiresIn: '4h' } // Shorter expiry for CBT
        );

        // Log CBT login
        await query(
            'INSERT INTO activity_logs (participant_id, action_type, description, ip_address) VALUES (?, ?, ?, ?)',
            [participant.id, 'cbt_login', 'CBT login successful', req.ip]
        );

        res.json({
            success: true,
            message: 'Login CBT berhasil',
            data: {
                token,
                participant: {
                    id: participant.id,
                    full_name: participant.full_name,
                    email: participant.email,
                    level: participant.level,
                    school_name: participant.school_name,
                    province: participant.province
                }
            }
        });

    } catch (error) {
        console.error('CBT login error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat login CBT'
        });
    }
});

// Verify token middleware
const verifyToken = (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
        return res.status(401).json({
            success: false,
            message: 'Token tidak ditemukan'
        });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default-secret-key');
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: 'Token tidak valid'
        });
    }
};

// Verify admin token
const verifyAdmin = (req, res, next) => {
    verifyToken(req, res, () => {
        if (req.user.role || req.user.type === 'admin') {
            next();
        } else {
            return res.status(403).json({
                success: false,
                message: 'Akses ditolak. Hanya admin yang diizinkan.'
            });
        }
    });
};

// Get current user info
router.get('/me', verifyToken, async (req, res) => {
    try {
        if (req.user.type === 'cbt_participant') {
            const participants = await query(
                'SELECT id, full_name, email, level, school_name, province FROM participants WHERE id = ?',
                [req.user.id]
            );
            
            if (participants.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Peserta tidak ditemukan'
                });
            }

            res.json({
                success: true,
                data: participants[0]
            });
        } else {
            const admins = await query(
                'SELECT id, name, email, role FROM admins WHERE id = ?',
                [req.user.id]
            );
            
            if (admins.length === 0) {
                return res.status(404).json({
                    success: false,
                    message: 'Admin tidak ditemukan'
                });
            }

            res.json({
                success: true,
                data: admins[0]
            });
        }

    } catch (error) {
        console.error('Get user info error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan'
        });
    }
});

module.exports = { router, verifyToken, verifyAdmin };