const express = require('express');
const router = express.Router();

// Import all routes
const { router: authRouter } = require('./auth');
const participantRouter = require('./participants');
const adminRouter = require('./admin');
const cbtRouter = require('./cbt');
const statisticsRouter = require('./statistics');
const uploadRouter = require('./upload');

// Use routes
router.use('/auth', authRouter);
router.use('/participants', participantRouter);
router.use('/admin', adminRouter);
router.use('/cbt', cbtRouter);
router.use('/statistics', statisticsRouter);
router.use('/upload', uploadRouter);

// Health check endpoint
router.get('/health', (req, res) => {
    res.json({
        success: true,
        message: 'MathVibe Indonesia API is running',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

module.exports = router;