const express = require('express');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { verifyToken } = require('./auth');
const router = express.Router();

// Ensure upload directory exists
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Upload configuration
const upload = (req, res, next) => {
    if (!req.files || Object.keys(req.files).length === 0) {
        return res.status(400).json({
            success: false,
            message: 'Tidak ada file yang diupload'
        });
    }

    const file = req.files.file;
    const maxSize = 10 * 1024 * 1024; // 10MB
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];

    // Validate file size
    if (file.size > maxSize) {
        return res.status(400).json({
            success: false,
            message: 'Ukuran file melebihi 10MB'
        });
    }

    // Validate file type
    if (!allowedTypes.includes(file.mimetype)) {
        return res.status(400).json({
            success: false,
            message: 'Format file tidak didukung. Gunakan JPG, PNG, atau PDF'
        });
    }

    // Generate unique filename
    const uniqueName = uuidv4() + path.extname(file.name);
    const uploadPath = path.join(uploadDir, uniqueName);

    // Move file to upload directory
    file.mv(uploadPath, (err) => {
        if (err) {
            console.error('File upload error:', err);
            return res.status(500).json({
                success: false,
                message: 'Terjadi kesalahan saat upload file'
            });
        }

        req.uploadedFile = {
            filename: uniqueName,
            originalName: file.name,
            mimetype: file.mimetype,
            size: file.size,
            path: uploadPath
        };

        next();
    });
};

// Upload social proof files
router.post('/social-proof', verifyToken, (req, res) => {
    upload(req, res, async () => {
        try {
            if (req.user.type !== 'cbt_participant') {
                return res.status(403).json({
                    success: false,
                    message: 'Hanya peserta yang dapat upload bukti sosial'
                });
            }

            const fileUrl = `/uploads/${req.uploadedFile.filename}`;

            // Update participant's social proof URLs
            const participants = await query(
                'SELECT social_proof_urls FROM participants WHERE id = ?',
                [req.user.id]
            );

            let socialProofUrls = [];
            if (participants[0].social_proof_urls) {
                socialProofUrls = JSON.parse(participants[0].social_proof_urls);
            }

            socialProofUrls.push(fileUrl);

            await query(
                'UPDATE participants SET social_proof_urls = ? WHERE id = ?',
                [JSON.stringify(socialProofUrls), req.user.id]
            );

            res.json({
                success: true,
                message: 'Bukti sosial berhasil diupload',
                data: {
                    file_url: fileUrl,
                    filename: req.uploadedFile.filename
                }
            });

        } catch (error) {
            console.error('Social proof upload error:', error);
            res.status(500).json({
                success: false,
                message: 'Terjadi kesalahan saat upload bukti sosial'
            });
        }
    });
});

// Upload payment proof
router.post('/payment-proof', verifyToken, (req, res) => {
    upload(req, res, async () => {
        try {
            if (req.user.type !== 'cbt_participant') {
                return res.status(403).json({
                    success: false,
                    message: 'Hanya peserta yang dapat upload bukti pembayaran'
                });
            }

            const fileUrl = `/uploads/${req.uploadedFile.filename}`;

            // Update participant's payment proof
            await query(
                'UPDATE participants SET payment_proof_url = ?, payment_status = ? WHERE id = ?',
                [fileUrl, 'pending', req.user.id]
            );

            res.json({
                success: true,
                message: 'Bukti pembayaran berhasil diupload',
                data: {
                    file_url: fileUrl,
                    filename: req.uploadedFile.filename
                }
            });

        } catch (error) {
            console.error('Payment proof upload error:', error);
            res.status(500).json({
                success: false,
                message: 'Terjadi kesalahan saat upload bukti pembayaran'
            });
        }
    });
});

// Upload question images (for admin)
router.post('/question-image', (req, res) => {
    upload(req, res, () => {
        try {
            const fileUrl = `/uploads/${req.uploadedFile.filename}`;

            res.json({
                success: true,
                message: 'Gambar soal berhasil diupload',
                data: {
                    file_url: fileUrl,
                    filename: req.uploadedFile.filename
                }
            });

        } catch (error) {
            console.error('Question image upload error:', error);
            res.status(500).json({
                success: false,
                message: 'Terjadi kesalahan saat upload gambar soal'
            });
        }
    });
});

// Get uploaded file
router.get('/file/:filename', (req, res) => {
    try {
        const filename = req.params.filename;
        const filePath = path.join(uploadDir, filename);

        // Security check - prevent directory traversal
        if (!filePath.startsWith(uploadDir)) {
            return res.status(403).json({
                success: false,
                message: 'Akses file ditolak'
            });
        }

        if (!fs.existsSync(filePath)) {
            return res.status(404).json({
                success: false,
                message: 'File tidak ditemukan'
            });
        }

        res.sendFile(filePath);

    } catch (error) {
        console.error('Get file error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil file'
        });
    }
});

// Delete uploaded file (admin only)
router.delete('/file/:filename', (req, res) => {
    try {
        const filename = req.params.filename;
        const filePath = path.join(uploadDir, filename);

        // Security check
        if (!filePath.startsWith(uploadDir)) {
            return res.status(403).json({
                success: false,
                message: 'Akses file ditolak'
            });
        }

        if (!fs.existsSync(filePath)) {
            return res.status(404).json({
                success: false,
                message: 'File tidak ditemukan'
            });
        }

        fs.unlinkSync(filePath);

        res.json({
            success: true,
            message: 'File berhasil dihapus'
        });

    } catch (error) {
        console.error('Delete file error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat menghapus file'
        });
    }
});

module.exports = router;