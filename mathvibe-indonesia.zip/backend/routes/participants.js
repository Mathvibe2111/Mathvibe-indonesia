const express = require('express');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const { query } = require('../config/database');
const { generateCBTPassword } = require('../utils/generatePassword');
const emailService = require('../utils/emailService');
const router = express.Router();

// Registration validation
const registrationValidation = [
    body('full_name').notEmpty().withMessage('Nama lengkap wajib diisi'),
    body('school_name').notEmpty().withMessage('Nama sekolah wajib diisi'),
    body('email').isEmail().withMessage('Email tidak valid'),
    body('phone').notEmpty().withMessage('Nomor HP wajib diisi'),
    body('level').isIn(['SMP', 'SMA']).withMessage('Jenjang harus SMP atau SMA'),
    body('province').notEmpty().withMessage('Provinsi wajib diisi')
];

// Register new participant
router.post('/register', registrationValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validasi gagal',
                errors: errors.array()
            });
        }

        const {
            full_name,
            school_name,
            email,
            phone,
            level,
            birth_date,
            address,
            province,
            social_proof_urls
        } = req.body;

        // Check if email already exists
        const existingParticipant = await query(
            'SELECT id FROM participants WHERE email = ?',
            [email]
        );

        if (existingParticipant.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Email sudah terdaftar'
            });
        }

        // Insert new participant
        const result = await query(`
            INSERT INTO participants 
            (full_name, school_name, email, phone, level, birth_date, address, province, social_proof_urls)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            full_name,
            school_name,
            email,
            phone,
            level,
            birth_date,
            address,
            province,
            JSON.stringify(social_proof_urls || [])
        ]);

        const participantId = result.insertId;

        // Send registration confirmation email
        await emailService.sendRegistrationConfirmation({
            full_name,
            school_name,
            email,
            phone,
            level
        });

        res.json({
            success: true,
            message: 'Pendaftaran berhasil',
            data: {
                participant_id: participantId,
                email: email
            }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat pendaftaran'
        });
    }
});

// Upload payment proof
router.post('/upload-payment/:participantId', async (req, res) => {
    try {
        const { participantId } = req.params;
        const { payment_proof_url } = req.body;

        if (!payment_proof_url) {
            return res.status(400).json({
                success: false,
                message: 'Bukti pembayaran wajib diupload'
            });
        }

        await query(
            'UPDATE participants SET payment_proof_url = ?, payment_status = ? WHERE id = ?',
            [payment_proof_url, 'pending', participantId]
        );

        res.json({
            success: true,
            message: 'Bukti pembayaran berhasil diupload'
        });

    } catch (error) {
        console.error('Upload payment error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat upload bukti pembayaran'
        });
    }
});

// Get participant by email
router.get('/check/:email', async (req, res) => {
    try {
        const { email } = req.params;
        
        const participants = await query(
            'SELECT id, full_name, email, phone, level, payment_status, social_proof_status FROM participants WHERE email = ?',
            [email]
        );

        if (participants.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Peserta tidak ditemukan'
            });
        }

        res.json({
            success: true,
            data: participants[0]
        });

    } catch (error) {
        console.error('Check participant error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan'
        });
    }
});

// Get all participants (for admin)
router.get('/', async (req, res) => {
    try {
        const { page = 1, limit = 10, search = '', level = 'all', status = 'all' } = req.query;
        const offset = (page - 1) * limit;

        let whereClause = 'WHERE 1=1';
        let params = [];

        if (search) {
            whereClause += ' AND (full_name LIKE ? OR email LIKE ? OR school_name LIKE ?)';
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }

        if (level !== 'all') {
            whereClause += ' AND level = ?';
            params.push(level);
        }

        if (status !== 'all') {
            whereClause += ' AND payment_status = ?';
            params.push(status);
        }

        const participants = await query(`
            SELECT 
                id, full_name, school_name, email, phone, level, province,
                payment_status, social_proof_status, cbt_password, status,
                score_preliminary, score_final, total_score, final_participant,
                registration_date
            FROM participants
            ${whereClause}
            ORDER BY registration_date DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(limit), parseInt(offset)]);

        const totalCount = await query(`
            SELECT COUNT(*) as total FROM participants ${whereClause}
        `, params);

        res.json({
            success: true,
            data: {
                participants,
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total: totalCount[0].total,
                    pages: Math.ceil(totalCount[0].total / limit)
                }
            }
        });

    } catch (error) {
        console.error('Get participants error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil data peserta'
        });
    }
});

// Verify payment (admin only)
router.put('/verify-payment/:participantId', async (req, res) => {
    try {
        const { participantId } = req.params;
        const { action, reason } = req.body; // action: 'verify' or 'reject'

        if (!['verify', 'reject'].includes(action)) {
            return res.status(400).json({
                success: false,
                message: 'Aksi tidak valid'
            });
        }

        // Get participant data
        const participant = await query(
            'SELECT * FROM participants WHERE id = ?',
            [participantId]
        );

        if (participant.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Peserta tidak ditemukan'
            });
        }

        const participantData = participant[0];

        if (action === 'verify') {
            // Generate CBT password
            const cbtPassword = generateCBTPassword(participantData.level, participantId);
            
            // Update participant
            await query(
                'UPDATE participants SET payment_status = ?, cbt_password = ? WHERE id = ?',
                ['verified', cbtPassword, participantId]
            );

            // Send email with CBT password
            await emailService.sendPaymentVerified({
                full_name: participantData.full_name,
                email: participantData.email,
                level: participantData.level,
                cbt_password: cbtPassword
            }, cbtPassword);

            res.json({
                success: true,
                message: 'Pembayaran berhasil diverifikasi dan password CBT telah dikirim',
                data: { cbt_password: cbtPassword }
            });

        } else {
            // Reject payment
            await query(
                'UPDATE participants SET payment_status = ?, status = ? WHERE id = ?',
                ['rejected', 'disqualified', participantId]
            );

            res.json({
                success: true,
                message: 'Pembayaran ditolak'
            });
        }

    } catch (error) {
        console.error('Verify payment error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat verifikasi pembayaran'
        });
    }
});

// Verify social proof (admin only)
router.put('/verify-social/:participantId', async (req, res) => {
    try {
        const { participantId } = req.params;
        const { status } = req.body; // 'verified' or 'rejected'

        if (!['verified', 'rejected'].includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Status tidak valid'
            });
        }

        await query(
            'UPDATE participants SET social_proof_status = ? WHERE id = ?',
            [status, participantId]
        );

        res.json({
            success: true,
            message: `Bukti sosial berhasil di${status === 'verified' ? 'verifikasi' : 'tolak'}`
        });

    } catch (error) {
        console.error('Verify social proof error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat verifikasi bukti sosial'
        });
    }
});

module.exports = router;