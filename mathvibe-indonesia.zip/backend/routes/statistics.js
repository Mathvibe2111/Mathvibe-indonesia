const express = require('express');
const router = express.Router();
const { query } = require('../config/database');

// Get public statistics
router.get('/public', async (req, res) => {
    try {
        const stats = await query(`
            SELECT 
                (SELECT COUNT(*) FROM participants) as total_registered,
                (SELECT COUNT(*) FROM participants WHERE payment_status = 'verified') as total_paid,
                (SELECT COUNT(DISTINCT province) FROM participants WHERE province IS NOT NULL) as total_provinces,
                (SELECT setting_value FROM system_settings WHERE setting_key = 'total_prize') as total_prize
        `);

        res.json({
            success: true,
            data: stats[0]
        });
    } catch (error) {
        console.error('Error fetching statistics:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching statistics'
        });
    }
});

// Get detailed statistics for admin
router.get('/admin', async (req, res) => {
    try {
        const stats = await query(`
            SELECT 
                COUNT(*) as total_participants,
                SUM(CASE WHEN payment_status = 'verified' THEN 1 ELSE 0 END) as verified_payments,
                SUM(CASE WHEN payment_status = 'pending' THEN 1 ELSE 0 END) as pending_payments,
                SUM(CASE WHEN payment_status = 'rejected' THEN 1 ELSE 0 END) as rejected_payments,
                SUM(CASE WHEN level = 'SMP' THEN 1 ELSE 0 END) as smp_participants,
                SUM(CASE WHEN level = 'SMA' THEN 1 ELSE 0 END) as sma_participants,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_exams,
                SUM(CASE WHEN final_participant = TRUE THEN 1 ELSE 0 END) as final_participants
            FROM participants
        `);

        const dailyRegistrations = await query(`
            SELECT 
                DATE(registration_date) as date,
                COUNT(*) as registrations
            FROM participants 
            WHERE registration_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY DATE(registration_date)
            ORDER BY date DESC
        `);

        const provinceStats = await query(`
            SELECT 
                province,
                COUNT(*) as participants,
                SUM(CASE WHEN payment_status = 'verified' THEN 1 ELSE 0 END) as verified
            FROM participants 
            WHERE province IS NOT NULL
            GROUP BY province
            ORDER BY participants DESC
        `);

        res.json({
            success: true,
            data: {
                overview: stats[0],
                dailyRegistrations,
                provinceStats
            }
        });
    } catch (error) {
        console.error('Error fetching admin statistics:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching statistics'
        });
    }
});

// Get leaderboard
router.get('/leaderboard', async (req, res) => {
    try {
        const { level = 'all', limit = 50 } = req.query;
        
        let whereClause = '';
        if (level !== 'all') {
            whereClause = `WHERE p.level = ? AND p.payment_status = 'verified'`;
        } else {
            whereClause = `WHERE p.payment_status = 'verified'`;
        }

        const leaderboard = await query(`
            SELECT 
                p.id,
                p.full_name,
                p.school_name,
                p.level,
                p.province,
                p.score_preliminary,
                p.score_final,
                p.total_score,
                p.rank_preliminary,
                p.rank_final,
                RANK() OVER (ORDER BY p.total_score DESC, p.score_final DESC) as global_rank,
                p.final_participant
            FROM participants p
            ${whereClause}
            ORDER BY p.total_score DESC, p.score_final DESC
            LIMIT ?
        `, level !== 'all' ? [level, parseInt(limit)] : [parseInt(limit)]);

        res.json({
            success: true,
            data: leaderboard
        });
    } catch (error) {
        console.error('Error fetching leaderboard:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching leaderboard'
        });
    }
});

module.exports = router;