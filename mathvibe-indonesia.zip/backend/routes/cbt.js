const express = require('express');
const { body, validationResult } = require('express-validator');
const { query } = require('../config/database');
const { verifyToken } = require('./auth');
const router = express.Router();

// Start exam session
router.post('/start-exam', verifyToken, async (req, res) => {
    try {
        // Check if user is a CBT participant
        if (req.user.type !== 'cbt_participant') {
            return res.status(403).json({
                success: false,
                message: 'Hanya peserta CBT yang dapat mengakses ujian'
            });
        }

        const participantId = req.user.id;
        const level = req.user.level;

        // Check if exam is already started
        const existingSession = await query(
            'SELECT * FROM exam_sessions WHERE participant_id = ? AND status = ?',
            [participantId, 'active']
        );

        if (existingSession.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Anda masih memiliki sesi ujian yang aktif'
            });
        }

        // Check if participant has completed preliminary round
        const participant = await query(
            'SELECT score_preliminary FROM participants WHERE id = ?',
            [participantId]
        );

        if (participant[0].score_preliminary > 0) {
            return res.status(400).json({
                success: false,
                message: 'Anda sudah menyelesaikan ujian penyisihan'
            });
        }

        // Create new exam session
        const duration = level === 'SMA' ? 45 * 60 : 30 * 60; // seconds
        
        const result = await query(
            'INSERT INTO exam_sessions (participant_id, level, session_type, duration) VALUES (?, ?, ?, ?)',
            [participantId, level, 'preliminary', duration]
        );

        // Get questions for the participant
        const questions = await query(
            'SELECT * FROM questions WHERE level = ? ORDER BY RAND()',
            [level]
        );

        // Limit questions based on level
        const maxQuestions = level === 'SMA' ? 40 : 30;
        const selectedQuestions = questions.slice(0, maxQuestions);

        res.json({
            success: true,
            message: 'Sesi ujian dimulai',
            data: {
                session_id: result.insertId,
                questions: selectedQuestions.map(q => ({
                    id: q.id,
                    question: q.question_text,
                    options: JSON.parse(q.options || '[]'),
                    question_type: q.question_type,
                    time_limit: q.time_limit
                })),
                duration: duration * 1000 // convert to milliseconds
            }
        });

    } catch (error) {
        console.error('Start exam error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat memulai ujian'
        });
    }
});

// Submit answer
router.post('/submit-answer', verifyToken, async (req, res) => {
    try {
        if (req.user.type !== 'cbt_participant') {
            return res.status(403).json({
                success: false,
                message: 'Hanya peserta CBT yang dapat mengirim jawaban'
            });
        }

        const { session_id, question_id, answer, time_spent } = req.body;

        // Validate input
        if (!session_id || !question_id) {
            return res.status(400).json({
                success: false,
                message: 'Session ID dan Question ID wajib diisi'
            });
        }

        // Check if session exists and is active
        const sessions = await query(
            'SELECT * FROM exam_sessions WHERE id = ? AND participant_id = ? AND status = ?',
            [session_id, req.user.id, 'active']
        );

        if (sessions.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Sesi ujian tidak valid atau sudah berakhir'
            });
        }

        // Get question details
        const questions = await query(
            'SELECT * FROM questions WHERE id = ?',
            [question_id]
        );

        if (questions.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Soal tidak ditemukan'
            });
        }

        const question = questions[0];
        const isCorrect = answer === question.correct_answer;
        const pointsEarned = isCorrect ? question.points_correct : (answer ? question.points_wrong : question.points_blank);

        // Check if answer already exists
        const existingAnswer = await query(
            'SELECT * FROM participant_answers WHERE session_id = ? AND question_id = ?',
            [session_id, question_id]
        );

        if (existingAnswer.length > 0) {
            // Update existing answer
            await query(
                'UPDATE participant_answers SET answer = ?, is_correct = ?, points_earned = ?, time_spent = ? WHERE session_id = ? AND question_id = ?',
                [answer, isCorrect, pointsEarned, time_spent, session_id, question_id]
            );
        } else {
            // Insert new answer
            await query(
                'INSERT INTO participant_answers (session_id, question_id, participant_id, answer, is_correct, points_earned, time_spent) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [session_id, question_id, req.user.id, answer, isCorrect, pointsEarned, time_spent]
            );
        }

        res.json({
            success: true,
            message: 'Jawaban berhasil disimpan',
            data: {
                is_correct: isCorrect,
                points_earned: pointsEarned,
                correct_answer: question.correct_answer
            }
        });

    } catch (error) {
        console.error('Submit answer error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat menyimpan jawaban'
        });
    }
});

// Finish exam
router.post('/finish-exam', verifyToken, async (req, res) => {
    try {
        if (req.user.type !== 'cbt_participant') {
            return res.status(403).json({
                success: false,
                message: 'Hanya peserta CBT yang dapat menyelesaikan ujian'
            });
        }

        const { session_id } = req.body;

        // Check if session exists and is active
        const sessions = await query(
            'SELECT * FROM exam_sessions WHERE id = ? AND participant_id = ? AND status = ?',
            [session_id, req.user.id, 'active']
        );

        if (sessions.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Sesi ujian tidak valid atau sudah berakhir'
            });
        }

        const session = sessions[0];

        // Calculate total score
        const answers = await query(
            'SELECT SUM(points_earned) as total_score FROM participant_answers WHERE session_id = ?',
            [session_id]
        );

        const totalScore = answers[0].total_score || 0;

        // Update exam session
        await query(
            'UPDATE exam_sessions SET end_time = NOW(), status = ?, total_score = ? WHERE id = ?',
            ['completed', totalScore, session_id]
        );

        // Update participant score
        await query(
            'UPDATE participants SET score_preliminary = ?, status = ? WHERE id = ?',
            [totalScore, 'completed', req.user.id]
        );

        // Log exam completion
        await query(
            'INSERT INTO activity_logs (participant_id, action_type, description, ip_address) VALUES (?, ?, ?, ?)',
            [req.user.id, 'exam_completed', `Exam completed with score: ${totalScore}`, req.ip]
        );

        res.json({
            success: true,
            message: 'Ujian berhasil diselesaikan',
            data: {
                total_score: totalScore,
                session_id: session_id
            }
        });

    } catch (error) {
        console.error('Finish exam error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat menyelesaikan ujian'
        });
    }
});

// Get exam results
router.get('/results', verifyToken, async (req, res) => {
    try {
        if (req.user.type !== 'cbt_participant') {
            return res.status(403).json({
                success: false,
                message: 'Hanya peserta CBT yang dapat melihat hasil'
            });
        }

        const participantId = req.user.id;

        // Get participant info with score
        const participants = await query(
            `SELECT p.id, p.full_name, p.email, p.level, p.school_name, p.province, 
                    p.score_preliminary, p.score_final, p.total_score
             FROM participants p 
             WHERE p.id = ?`,
            [participantId]
        );

        if (participants.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Peserta tidak ditemukan'
            });
        }

        const participant = participants[0];

        // Get exam sessions
        const sessions = await query(
            `SELECT es.*, COUNT(pa.id) as questions_answered
             FROM exam_sessions es
             LEFT JOIN participant_answers pa ON es.id = pa.session_id
             WHERE es.participant_id = ?
             GROUP BY es.id
             ORDER BY es.start_time DESC`,
            [participantId]
        );

        // Get detailed answers for latest session
        let detailedAnswers = [];
        if (sessions.length > 0) {
            detailedAnswers = await query(
                `SELECT pa.*, q.question_text, q.correct_answer
                 FROM participant_answers pa
                 JOIN questions q ON pa.question_id = q.id
                 WHERE pa.session_id = ?
                 ORDER BY pa.answered_at`,
                [sessions[0].id]
            );
        }

        res.json({
            success: true,
            data: {
                participant,
                sessions,
                detailed_answers: detailedAnswers
            }
        });

    } catch (error) {
        console.error('Get results error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil hasil'
        });
    }
});

// Get leaderboard
router.get('/leaderboard', verifyToken, async (req, res) => {
    try {
        const { level = 'all', limit = 50 } = req.query;
        
        let whereClause = '';
        let params = [];

        if (level !== 'all') {
            whereClause = 'WHERE p.level = ? AND p.payment_status = ?';
            params = [level, 'verified'];
        } else {
            whereClause = 'WHERE p.payment_status = ?';
            params = ['verified'];
        }

        const leaderboard = await query(`
            SELECT 
                p.id,
                p.full_name,
                p.school_name,
                p.level,
                p.province,
                p.score_preliminary,
                p.score_final,
                p.total_score,
                RANK() OVER (ORDER BY p.total_score DESC, p.score_final DESC) as rank,
                p.final_participant
            FROM participants p
            ${whereClause}
            ORDER BY p.total_score DESC, p.score_final DESC
            LIMIT ?
        `, [...params, parseInt(limit)]);

        res.json({
            success: true,
            data: leaderboard
        });

    } catch (error) {
        console.error('Get leaderboard error:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat mengambil leaderboard'
        });
    }
});

module.exports = router;