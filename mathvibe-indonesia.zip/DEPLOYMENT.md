# MathVibe Indonesia - Deployment Guide

## 🚀 Deployment Options

### 1. Local Development
```bash
# Backend
cd backend
npm install
npm run dev

# Frontend
cd frontend
npm install
npm run dev
```

### 2. Production Deployment

#### Using PM2 (Recommended)
```bash
# Install PM2 globally
npm install -g pm2

# Backend
cd backend
pm2 start server.js --name "mathvibe-backend"

# Frontend (after build)
cd frontend
npm run build
pm2 start "npm start" --name "mathvibe-frontend"
```

#### Using Docker (Optional)
```dockerfile
# Backend Dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

## 🌐 Cloud Deployment

### Vercel (Frontend)
1. Push code to GitHub
2. Connect repository to Vercel
3. Set environment variables
4. Deploy

### Heroku (Backend)
1. Create Heroku app
2. Add MySQL addon (JawsDB)
3. Set environment variables
4. Deploy

### AWS EC2
1. Launch EC2 instance
2. Install Node.js and MySQL
3. Clone repository
4. Setup PM2 and Nginx
5. Configure SSL

## 🔧 Production Configuration

### Environment Variables
```bash
# Backend
NODE_ENV=production
PORT=5000
DB_HOST=your-db-host
JWT_SECRET=your-secure-jwt-secret
SMTP_USER=your-email
SMTP_PASS=your-app-password

# Frontend
NEXT_PUBLIC_API_URL=https://your-api-domain.com
```

### SSL Certificate
```bash
# Using Let's Encrypt
sudo apt install certbot
sudo certbot --nginx -d yourdomain.com
```

### Database Optimization
```sql
-- Add indexes
CREATE INDEX idx_participants_email ON participants(email);
CREATE INDEX idx_participants_payment ON participants(payment_status);
CREATE INDEX idx_questions_level ON questions(level);
```

## 📊 Monitoring

### PM2 Monitoring
```bash
pm2 list
pm2 logs
pm2 monit
```

### Database Monitoring
```bash
# Check MySQL status
sudo systemctl status mysql

# Check slow queries
mysql -u root -p
SHOW PROCESSLIST;
```

## 🔄 CI/CD Pipeline

### GitHub Actions
```yaml
name: Deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to server
        run: |
          # Add deployment commands here
```

## 🚨 Troubleshooting

### Common Issues

1. **Database Connection**
   - Check MySQL service status
   - Verify credentials
   - Check firewall settings

2. **File Upload Errors**
   - Check upload directory permissions
   - Verify disk space
   - Check file size limits

3. **Email Not Sending**
   - Verify SMTP credentials
   - Check Gmail App Password
   - Check spam folder

4. **CORS Errors**
   - Verify FRONTEND_URL in backend .env
   - Check CORS configuration
   - Ensure same protocol (http/https)

## 📈 Performance Tips

1. **Enable Gzip Compression**
2. **Use CDN for static assets**
3. **Implement caching (Redis)**
4. **Optimize images**
5. **Use database connection pooling**

## 🔒 Security Checklist

- [ ] HTTPS enabled
- [ ] Environment variables secured
- [ ] Database credentials encrypted
- [ ] File upload validation
- [ ] Rate limiting enabled
- [ ] JWT secrets rotated
- [ ] Regular security updates

## 📞 Emergency Contacts

For deployment issues:
- Technical Support: admin@mathvibe.id
- Emergency: 0822-7497-3133